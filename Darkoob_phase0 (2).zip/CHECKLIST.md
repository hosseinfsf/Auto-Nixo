# Darkoob Master Checklist

- Updated: `2026-11-27T14:04:33.535Z`
- Total tasks: `159`

| ID | Phase | Status | Title | Depends On | Evidence Class |
|---|---|---|---|---|---|
| T-001 | 0 | NOT_STARTED | Inspect working dir; detect existing Darkoob project, checklist, STATE.md, git repo | - | - |
| T-002 | 0 | NOT_STARTED | If resuming: verify last 3 PASSED tasks by re-running their tests | T-001 | - |
| T-003 | 0 | NOT_STARTED | Create D:\AutoTrades\Darkoob, git init, .gitignore (§9), commit | T-001 | - |
| T-004 | 0 | NOT_STARTED | Create CHECKLIST.json/.md, STATE.md, QUESTIONS.md, Reports/, DECISIONS/, LICENSES/ | T-003 | - |
| T-005 | 0 | NOT_STARTED | Write Reports/00_Project_Overview.md (scope, milestones, risks) | T-004 | - |
| T-006 | 0 | NOT_STARTED | Write safety statement: no changes to existing installs; list of forbidden paths | T-004 | - |
| T-007 | 0 | NOT_STARTED | Add pre-commit/secret-scan script (regex for api_hash, phone, sessions, keys) | T-003 | - |
| T-010 | 1 | NOT_STARTED | Windows version, RAM, CPU, disk | T-004 | - |
| T-011 | 1 | NOT_STARTED | Python versions present; create 3.12 venv | T-010 | - |
| T-012 | 1 | NOT_STARTED | Git, Node (only if needed), internet reachability to github.com/pypi.org | T-010 | - |
| T-013 | 1 | NOT_STARTED | MT5 terminal detection (path, build, demo accounts, algo-trading flag) - read-only | T-010 | - |
| T-014 | 1 | NOT_STARTED | Dependency shortlist with licenses | T-011 | - |
| T-015 | 1 | NOT_STARTED | Reports/01_Environment_Audit.md | T-010, T-011, T-012, T-013, T-014 | - |
| T-020 | 2 | NOT_STARTED | Clone both primary repos into _src/, record commit hashes (read-only) | T-012 | - |
| T-021 | 2 | NOT_STARTED | Read actual LICENSE of each; fill LICENSE_REGISTRY.md with obligations | T-020 | - |
| T-022 | 2 | NOT_STARTED | License Gate G2 request to human for each repo | T-021 | - |
| T-023 | 2 | NOT_STARTED | Full structure inventory of FluentSignalCopier (files, deps, tests) | T-020 | - |
| T-024 | 2 | NOT_STARTED | Full structure inventory of forex-gold incl. backend/src/services/*, frontend, mql5, tests, docs, tools | T-020 | - |
| T-025 | 2 | NOT_STARTED | Run upstream test suites of both repos in isolated venvs; record raw results separately | T-020, T-011 | - |
| T-026 | 2 | NOT_STARTED | Read-only protocol analysis: forex-gold EA + mt5_bridge.py | T-024 | - |
| T-027 | 2 | NOT_STARTED | Fluent output protocol analysis (telegram_signals.jsonl schema) | T-023 | - |
| T-028 | 2 | NOT_STARTED | Find & evaluate >=30 additional repos with research matrix | T-012 | - |
| T-029 | 2 | NOT_STARTED | OCR/Vision benchmark plan + quick benchmark on 20 sample charts | T-011 | - |
| T-030 | 2 | NOT_STARTED | Reuse-vs-write Decision Records for Telegram, parser, DB, risk, MT5, OCR, dashboard | T-023, T-024, T-025, T-026, T-027, T-028, T-029 | - |
| T-031 | 2 | NOT_STARTED | SOURCE_MAPPING.md skeleton + Reports/02_Open_Source_Research.md | T-030 | - |
| T-040 | 3 | NOT_STARTED | Create directory layout (§10.3) only for folders with content | T-031 | - |
| T-041 | 3 | NOT_STARTED | Copy approved upstream files unchanged into vendor/<repo>/ with LICENSE | T-022 | - |
| T-042 | 3 | NOT_STARTED | Preserve license texts in LICENSES/ and in each vendor folder | T-041 | - |
| T-043 | 3 | NOT_STARTED | Dependency lock file; install into venv | T-014 | - |
| T-044 | 3 | NOT_STARTED | Re-run upstream tests from vendor/ copies | T-043 | - |
| T-045 | 3 | NOT_STARTED | Patch files for known upstream defects (§10.2) + regression tests | T-044 | - |
| T-046 | 3 | NOT_STARTED | Config system (typed settings, .env, config/*.yaml, validation, redaction) | T-043 | - |
| T-047 | 3 | NOT_STARTED | Logging framework with redaction filter | T-046 | - |
| T-048 | 3 | NOT_STARTED | Phase 3 report + commit tag | T-041, T-042, T-043, T-044, T-045, T-046, T-047 | - |
| T-050 | 4 | NOT_STARTED | Schema design doc (ER diagram, pipeline states, message versions) | T-048 | - |
| T-051 | 4 | NOT_STARTED | Connection layer, WAL, busy timeout, single-writer strategy | T-050 | - |
| T-052 | 4 | NOT_STARTED | Migration framework + initial migration | T-051 | - |
| T-053 | 4 | NOT_STARTED | Tables: sources/channels, raw_messages(+versions), media, ocr/ai, signals, validation, risk | T-052 | - |
| T-054 | 4 | NOT_STARTED | Tables: commands, acks, orders, positions, trade events, roulette, audit, events | T-052 | - |
| T-055 | 4 | NOT_STARTED | Repository/DAO layer (adapter over vendor where DR specifies) | T-053 | - |
| T-056 | 4 | NOT_STARTED | Crash-recovery test: kill mid-transaction/pipeline and resume | T-055 | - |
| T-057 | 4 | NOT_STARTED | Backup/restore + integrity check script | T-055 | - |
| T-060 | 5 | NOT_STARTED | Settings: api_id/hash/phone/session path; secure storage | T-046 | - |
| T-061 | 5 | NOT_STARTED | Auth flow incl. 2FA | T-060 | - |
| T-062 | 5 | NOT_STARTED | Session persistence + restart reuse | T-061 | - |
| T-063 | 5 | NOT_STARTED | Single-instance lock for one session | T-062 | - |
| T-064 | 5 | NOT_STARTED | Connect one channel; resolve by id/username/invite | T-062 | - |
| T-065 | 5 | NOT_STARTED | Receive text -> store raw-first | T-064, T-053 | - |
| T-066 | 5 | NOT_STARTED | Receive images/media (download, hash, size/type validation) | T-065 | - |
| T-067 | 5 | NOT_STARTED | Albums, captions, replies, forwards | T-066 | - |
| T-068 | 5 | NOT_STARTED | Multi-channel with independent states and isolation | T-065 | - |
| T-069 | 5 | NOT_STARTED | Edit detection -> new version, delete events | T-065 | - |
| T-070 | 5 | NOT_STARTED | Idempotency (chat,msg,version) | T-065 | - |
| T-071 | 5 | NOT_STARTED | Reconnect with backoff+jitter, error classification | T-064 | - |
| T-072 | 5 | NOT_STARTED | FloodWait handling | T-071 | - |
| T-073 | 5 | NOT_STARTED | Catch-up from last id + recent-edit re-check + periodic reconcile | T-070 | - |
| T-074 | 5 | NOT_STARTED | Listener as isolated process + heartbeat | T-071 | - |
| T-075 | 5 | NOT_STARTED | Per-channel status model & metrics | T-068 | - |
| T-076 | 5 | NOT_STARTED | Listener integration test suite (scenarios 1-7, 27, 28) | T-073 | - |
| T-077 | 5 | NOT_STARTED | Reports/05_Telegram_Implementation.md | T-076 | - |
| T-080 | 6 | NOT_STARTED | Signal schema (JSON Schema, versioned) + validator | T-050 | - |
| T-081 | 6 | NOT_STARTED | Labeled message fixture set >=120 (+ Persian/Arabic digits, emoji, negatives) | T-050 | - |
| T-082 | 6 | NOT_STARTED | Adapter around Fluent parser (vendor+patch) -> schema | T-045, T-080 | - |
| T-083 | 6 | NOT_STARTED | Adapter around forex-gold parser -> schema | T-080 | - |
| T-084 | 6 | NOT_STARTED | Parser comparison report -> DR for selection/combination | T-082, T-083 | - |
| T-085 | 6 | NOT_STARTED | Intent classifier (13 classes) | T-084 | - |
| T-086 | 6 | NOT_STARTED | Message clustering into signal IDs | T-085 | - |
| T-087 | 6 | NOT_STARTED | Update handling: entry/SL/TP change, BE, partial, close, cancel | T-086 | - |
| T-088 | 6 | NOT_STARTED | Symbol alias/broker suffix normalization | T-080 | - |
| T-089 | 6 | NOT_STARTED | Number normalization (locales, Persian digits, separators) | T-080 | - |
| T-090 | 6 | NOT_STARTED | Known-defect regression tests from §10.2 | T-045 | - |
| T-091 | 6 | NOT_STARTED | Wire listener -> classifier -> parser -> DB (state machine) | T-076, T-087 | - |
| T-092 | 6 | NOT_STARTED | Reports/06_Signal_Extraction.md (Milestone M1 report) | T-091 | - |
| T-100 | 7 | NOT_STARTED | Validation rules engine (§14.1) with machine-readable reasons | T-080 | - |
| T-101 | 7 | NOT_STARTED | Broker symbol spec provider (interface; MT5 + fake) | T-100 | - |
| T-102 | 7 | NOT_STARTED | Duplicate/expiry/contradiction checks | T-100 | - |
| T-103 | 7 | NOT_STARTED | Confidence thresholds + manual review queue | T-100 | - |
| T-104 | 7 | NOT_STARTED | Risk config model (global/account/channelxaccount/trade hierarchy) | T-046 | - |
| T-105 | 7 | NOT_STARTED | Position sizing formula doc + implementation | T-101, T-104 | - |
| T-106 | 7 | NOT_STARTED | Lot rounding/min/max/step, margin check | T-105 | - |
| T-107 | 7 | NOT_STARTED | Daily loss / drawdown / exposure / open-orders limits | T-104 | - |
| T-108 | 7 | NOT_STARTED | Multi-TP volume split, partial-close plan (no invented TPs) | T-105 | - |
| T-109 | 7 | NOT_STARTED | Roulette state model (per accountxchannel) + persistence | T-054, T-104 | - |
| T-110 | 7 | NOT_STARTED | Roulette progression, reset, hard caps, manual reset | T-109 | - |
| T-111 | 7 | NOT_STARTED | Outcome classification from final realized results | T-109 | - |
| T-112 | 7 | NOT_STARTED | Prove AI/parser output cannot bypass Risk | T-104 | - |
| T-113 | 7 | NOT_STARTED | Reports 08, 09, 10 | T-110 | - |
| T-120 | 8 | NOT_STARTED | Image labeled dataset >=80 (real + synthetic flagged) with JSON ground truth | T-066 | - |
| T-121 | 8 | NOT_STARTED | Image validation & limits (magic bytes, dims, bomb guard) | T-066 | - |
| T-122 | 8 | NOT_STARTED | Preprocessing pipeline (derived images retained) | T-121 | - |
| T-123 | 8 | NOT_STARTED | OCR engine adapter + number/symbol extraction | T-029, T-122 | - |
| T-124 | 8 | NOT_STARTED | Chart geometry: line/zone detection, axis calibration, pixel<->price | T-122 | - |
| T-125 | 8 | NOT_STARTED | Vision provider interface + schema-validated output | T-080 | - |
| T-126 | 8 | NOT_STARTED | Adapters: Gemini, OpenRouter, Cloudflare, Ollama, OpenAI-compatible | T-125 | - |
| T-127 | 8 | NOT_STARTED | Prompt-injection defense (image text = data) + tests | T-125 | - |
| T-128 | 8 | NOT_STARTED | Quota/cache/rate-limit manager | T-125 | - |
| T-129 | 8 | NOT_STARTED | Candidate fusion (OCR, Vision, caption, geometry) + disagreement recording | T-123, T-124, T-125 | - |
| T-130 | 8 | NOT_STARTED | Confidence model + calibration on dataset | T-129 | - |
| T-131 | 8 | NOT_STARTED | Image pipeline worker (bounded concurrency, non-blocking) | T-129 | - |
| T-132 | 8 | NOT_STARTED | Dataset benchmark run + Reports/07_Vision_AI.md | T-130 | - |
| T-133 | 8 | NOT_STARTED | Image-scenarios 8,9,14,15,16,17,18,25,26 of §16 | T-131 | - |
| T-140 | 9 | NOT_STARTED | DR: forex-gold EA bridge vs MetaTrader5 Python API vs hybrid | T-026, T-030 | - |
| T-141 | 9 | NOT_STARTED | Execution command schema (command_id, idempotency key, magic, signal_id) | T-054 | - |
| T-142 | 9 | NOT_STARTED | Durable command queue (persist-before-send) | T-141 | - |
| T-143 | 9 | NOT_STARTED | MT5 adapter: connect, account info, DEMO-account assertion | T-140 | - |
| T-144 | 9 | NOT_STARTED | Symbol mapping + live quotes/spread | T-143 | - |
| T-145 | 9 | NOT_STARTED | Market + pending orders with SL/TP | T-143 | - |
| T-146 | 9 | NOT_STARTED | Ack handling + post-send verification of order/position | T-145 | - |
| T-147 | 9 | NOT_STARTED | Duplicate-execution protection | T-142, T-146 | - |
| T-148 | 9 | NOT_STARTED | Modify SL/TP, break-even, trailing, partial close | T-145 | - |
| T-149 | 9 | NOT_STARTED | Close by signal/channel/account/all-managed; foreign untouched | T-148 | - |
| T-150 | 9 | NOT_STARTED | Position monitor + trade-result recording | T-146 | - |
| T-151 | 9 | NOT_STARTED | Connection monitor + reconnect + disconnect-during-send | T-143 | - |
| T-152 | 9 | NOT_STARTED | Real-trading hard gate tests | T-143 | - |
| T-153 | 9 | NOT_STARTED | E2E: text signal -> validation -> risk -> MT5 DEMO order -> close (Milestone M2) | T-147, T-148, T-149, T-150 | - |
| T-160 | 10 | NOT_STARTED | DR + app shell bound to 127.0.0.1 | T-030 | - |
| T-161 | 10 | NOT_STARTED | Overview page (real data, data-state labels) | T-160 | - |
| T-162 | 10 | NOT_STARTED | Telegram sources page (auth, channels, status, start/stop) | T-077 | - |
| T-163 | 10 | NOT_STARTED | Live feed + signal inbox | T-091 | - |
| T-164 | 10 | NOT_STARTED | Signal review + image analysis | T-129 | - |
| T-165 | 10 | NOT_STARTED | AI settings (secure key entry, test connection, quota) | T-128 | - |
| T-166 | 10 | NOT_STARTED | Accounts + risk + roulette pages (per channelxaccount) | T-110 | - |
| T-167 | 10 | NOT_STARTED | MT5 + trade management pages | T-150 | - |
| T-168 | 10 | NOT_STARTED | Reports & journal (§15 metrics) | T-050 | - |
| T-169 | 10 | NOT_STARTED | System health/logs page | T-160 | - |
| T-170 | 10 | NOT_STARTED | API input validation + auth for remote flag | T-160 | - |
| T-171 | 10 | NOT_STARTED | Dashboard E2E tests | T-169 | - |
| T-180 | 11 | NOT_STARTED | Heartbeat framework for all components | T-074 | - |
| T-181 | 11 | NOT_STARTED | Queue-depth and stale-signal monitors | T-142 | - |
| T-182 | 11 | NOT_STARTED | Watchdog with duplicate-safe recovery | T-147 | - |
| T-183 | 11 | NOT_STARTED | Graceful shutdown/startup sequencing | T-182 | - |
| T-184 | 11 | NOT_STARTED | Alerts (dashboard + optional Telegram self-message) | T-180 | - |
| T-190 | 12 | NOT_STARTED | Wire text path end-to-end under supervisor | T-153, T-184 | - |
| T-191 | 12 | NOT_STARTED | Wire image path end-to-end | T-133, T-190 | - |
| T-192 | 12 | NOT_STARTED | Lifecycle audit-trail check: Message->Result | T-190 | - |
| T-193 | 12 | NOT_STARTED | Run the full §16 scenario list (all 28) | T-191 | - |
| T-194 | 12 | NOT_STARTED | Regression suite (all prior tests) green | T-193 | - |
| T-200 | 13 | NOT_STARTED | Secret scan of repo, reports, logs, DB dumps | T-194 | - |
| T-201 | 13 | NOT_STARTED | Session/credential storage review; file ACLs | T-200 | - |
| T-202 | 13 | NOT_STARTED | Network exposure review (ports, bind addresses) | T-200 | - |
| T-203 | 13 | NOT_STARTED | Upload/image handling & resource-limit review | T-121 | - |
| T-204 | 13 | NOT_STARTED | Dependency audit (pip-audit) + license check | T-043 | - |
| T-205 | 13 | NOT_STARTED | Resource measurement (CPU/RAM idle, load) | T-194 | - |
| T-206 | 13 | NOT_STARTED | 24 h soak test (DEMO) | T-194 | - |
| T-207 | 13 | NOT_STARTED | Reports 13, 15 | T-206 | - |
| T-210 | 14 | NOT_STARTED | Install guide + config templates + first-run wizard | T-194 | - |
| T-211 | 14 | NOT_STARTED | Start/stop scripts, optional Task Scheduler/service wrapper | T-183 | - |
| T-212 | 14 | NOT_STARTED | Restart/recovery test on real Windows reboot | T-211 | - |
| T-213 | 14 | NOT_STARTED | Backup/restore drill | T-057 | - |
| T-214 | 14 | NOT_STARTED | Packaging evaluation (venv zip vs installer) - DR | T-210 | - |
| T-215 | 14 | NOT_STARTED | Release package (no secrets, no _src, no venv) | T-200 | - |
| T-216 | 14 | NOT_STARTED | Report 16 | T-215 | - |
| T-220 | 15 | NOT_STARTED | Verify every checklist entry has evidence; re-run random 20% of tests | - | - |
| T-221 | 15 | NOT_STARTED | Full automated test run | T-220 | - |
| T-222 | 15 | NOT_STARTED | DEMO end-to-end acceptance session (text + image) | T-221 | - |
| T-223 | 15 | NOT_STARTED | Verify SOURCE_MAPPING hashes again | T-221 | - |
| T-224 | 15 | NOT_STARTED | Verify LICENSE_REGISTRY + notices in package | T-223 | - |
| T-225 | 15 | NOT_STARTED | MISSING.md and honest limitation list | T-221 | - |
| T-226 | 15 | NOT_STARTED | FINAL_ACCEPTANCE.md using §19 categories | T-225 | - |
