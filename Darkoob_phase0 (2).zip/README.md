# Darkoob — Local Trading Signal & Risk Automation Workspace

- **Target Root:** `D:\AutoTrades\Darkoob`
- **Runtime:** Windows 11, Python 3.12 (no GPU required)
- **Safety Policy:** See `docs/SAFETY.md` (`REAL_TRADING=false`, `DEMO_MODE=true` by default)

## Quickstart (PowerShell)
1. Extract this archive into `D:\AutoTrades\Darkoob`.
2. Create and activate a Python 3.12 virtual environment:
   ```powershell
   py -3.12 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```
3. Run verification & unit tests:
   ```powershell
   python scripts/render_checklist.py
   python scripts/verify_checklist.py
   python scripts/secret_scan.py --self-test
   pytest -q tests/test_darkoob_core.py
   ```
4. Start the localhost-only (`127.0.0.1`) status API:
   ```powershell
   python -m darkoob.dashboard_api
   ```
