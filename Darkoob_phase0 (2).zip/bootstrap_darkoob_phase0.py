from __future__ import annotations

import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"D:\AutoTrades\Darkoob")
ZIP_OUT = Path(r"D:\AutoTrades\Darkoob_phase0.zip")

TASKS = [
    [
        "T-001",
        0,
        "Inspect working dir; detect existing Darkoob project, checklist, STATE.md, git repo",
        [],
        [
            "Written inventory; decision resume vs fresh recorded"
        ]
    ],
    [
        "T-002",
        0,
        "If resuming: verify last 3 PASSED tasks by re-running their tests",
        [
            "T-001"
        ],
        [
            "Each re-run output saved; mismatches set REGRESSED"
        ]
    ],
    [
        "T-003",
        0,
        "Create D:\\AutoTrades\\Darkoob, git init, .gitignore (§9), commit",
        [
            "T-001"
        ],
        [
            "git log shows first commit; secrets patterns ignored (git check-ignore)"
        ]
    ],
    [
        "T-004",
        0,
        "Create CHECKLIST.json/.md, STATE.md, QUESTIONS.md, Reports/, DECISIONS/, LICENSES/",
        [
            "T-003"
        ],
        [
            "Files exist; JSON validates; MD generated from JSON"
        ]
    ],
    [
        "T-005",
        0,
        "Write Reports/00_Project_Overview.md (scope, milestones, risks)",
        [
            "T-004"
        ],
        [
            "Report exists, follows template"
        ]
    ],
    [
        "T-006",
        0,
        "Write safety statement: no changes to existing installs; list of forbidden paths",
        [
            "T-004"
        ],
        [
            "File in docs/; referenced by README"
        ]
    ],
    [
        "T-007",
        0,
        "Add pre-commit/secret-scan script (regex for api_hash, phone, sessions, keys)",
        [
            "T-003"
        ],
        [
            "Script fails on planted dummy secret, passes clean tree"
        ]
    ],
    [
        "T-010",
        1,
        "Windows version, RAM, CPU, disk",
        [
            "T-004"
        ],
        [
            "Values recorded in report"
        ]
    ],
    [
        "T-011",
        1,
        "Python versions present; create 3.12 venv",
        [
            "T-010"
        ],
        [
            "python --version in venv = 3.12.x"
        ]
    ],
    [
        "T-012",
        1,
        "Git, Node (only if needed), internet reachability to github.com/pypi.org",
        [
            "T-010"
        ],
        [
            "Each check pass/fail logged"
        ]
    ],
    [
        "T-013",
        1,
        "MT5 terminal detection (path, build, demo accounts, algo-trading flag) - read-only",
        [
            "T-010"
        ],
        [
            "Report lists terminals found; no credentials stored"
        ]
    ],
    [
        "T-014",
        1,
        "Dependency shortlist with licenses",
        [
            "T-011"
        ],
        [
            "Table with SPDX ids"
        ]
    ],
    [
        "T-015",
        1,
        "Reports/01_Environment_Audit.md",
        [
            "T-010",
            "T-011",
            "T-012",
            "T-013",
            "T-014"
        ],
        [
            "Report complete"
        ]
    ],
    [
        "T-020",
        2,
        "Clone both primary repos into _src/, record commit hashes (read-only)",
        [
            "T-012"
        ],
        [
            "Hashes in SOURCE_MAPPING.md"
        ]
    ],
    [
        "T-021",
        2,
        "Read actual LICENSE of each; fill LICENSE_REGISTRY.md with obligations",
        [
            "T-020"
        ],
        [
            "Table complete; conflicts stated explicitly"
        ]
    ],
    [
        "T-022",
        2,
        "License Gate G2 request to human for each repo",
        [
            "T-021"
        ],
        [
            "Written answer recorded in QUESTIONS.md"
        ]
    ],
    [
        "T-023",
        2,
        "Full structure inventory of FluentSignalCopier (files, deps, tests)",
        [
            "T-020"
        ],
        [
            "Inventory file with LOC/size/imports"
        ]
    ],
    [
        "T-024",
        2,
        "Full structure inventory of forex-gold incl. backend/src/services/*, frontend, mql5, tests, docs, tools",
        [
            "T-020"
        ],
        [
            "Inventory + import graph"
        ]
    ],
    [
        "T-025",
        2,
        "Run upstream test suites of both repos in isolated venvs; record raw results separately",
        [
            "T-020",
            "T-011"
        ],
        [
            "Pass/fail counts + logs"
        ]
    ],
    [
        "T-026",
        2,
        "Read-only protocol analysis: forex-gold EA + mt5_bridge.py",
        [
            "T-024"
        ],
        [
            "docs/protocols/mt5_bridge.md from real code"
        ]
    ],
    [
        "T-027",
        2,
        "Fluent output protocol analysis (telegram_signals.jsonl schema)",
        [
            "T-023"
        ],
        [
            "Doc + EA compatibility statement"
        ]
    ],
    [
        "T-028",
        2,
        "Find & evaluate >=30 additional repos with research matrix",
        [
            "T-012"
        ],
        [
            "Matrix with evidence per repo; >=10 deeply inspected"
        ]
    ],
    [
        "T-029",
        2,
        "OCR/Vision benchmark plan + quick benchmark on 20 sample charts",
        [
            "T-011"
        ],
        [
            "Accuracy/latency/RAM table on 8GB machine"
        ]
    ],
    [
        "T-030",
        2,
        "Reuse-vs-write Decision Records for Telegram, parser, DB, risk, MT5, OCR, dashboard",
        [
            "T-023",
            "T-024",
            "T-025",
            "T-026",
            "T-027",
            "T-028",
            "T-029"
        ],
        [
            "One DR per item with >=2 options"
        ]
    ],
    [
        "T-031",
        2,
        "SOURCE_MAPPING.md skeleton + Reports/02_Open_Source_Research.md",
        [
            "T-030"
        ],
        [
            "Reports complete"
        ]
    ],
    [
        "T-040",
        3,
        "Create directory layout (§10.3) only for folders with content",
        [
            "T-031"
        ],
        [
            "Tree matches DR; no empty placeholder dirs"
        ]
    ],
    [
        "T-041",
        3,
        "Copy approved upstream files unchanged into vendor/<repo>/ with LICENSE",
        [
            "T-022"
        ],
        [
            "Source+dest SHA-256 equal in SOURCE_MAPPING.md"
        ]
    ],
    [
        "T-042",
        3,
        "Preserve license texts in LICENSES/ and in each vendor folder",
        [
            "T-041"
        ],
        [
            "Files byte-equal to upstream LICENSE"
        ]
    ],
    [
        "T-043",
        3,
        "Dependency lock file; install into venv",
        [
            "T-014"
        ],
        [
            "pip freeze saved; reproducible install"
        ]
    ],
    [
        "T-044",
        3,
        "Re-run upstream tests from vendor/ copies",
        [
            "T-043"
        ],
        [
            "Results equal T-025 or differences explained"
        ]
    ],
    [
        "T-045",
        3,
        "Patch files for known upstream defects (§10.2) + regression tests",
        [
            "T-044"
        ],
        [
            "Patch applies cleanly; vendor originals unchanged"
        ]
    ],
    [
        "T-046",
        3,
        "Config system (typed settings, .env, config/*.yaml, validation, redaction)",
        [
            "T-043"
        ],
        [
            "Unit tests + no secret in logs"
        ]
    ],
    [
        "T-047",
        3,
        "Logging framework with redaction filter",
        [
            "T-046"
        ],
        [
            "Test proves secrets masked"
        ]
    ],
    [
        "T-048",
        3,
        "Phase 3 report + commit tag",
        [
            "T-041",
            "T-042",
            "T-043",
            "T-044",
            "T-045",
            "T-046",
            "T-047"
        ],
        [
            "Report complete"
        ]
    ],
    [
        "T-050",
        4,
        "Schema design doc (ER diagram, pipeline states, message versions)",
        [
            "T-048"
        ],
        [
            "Reviewed against §11-15 field list"
        ]
    ],
    [
        "T-051",
        4,
        "Connection layer, WAL, busy timeout, single-writer strategy",
        [
            "T-050"
        ],
        [
            "Concurrency test no corruption/locked errors"
        ]
    ],
    [
        "T-052",
        4,
        "Migration framework + initial migration",
        [
            "T-051"
        ],
        [
            "Up/down + idempotent re-run"
        ]
    ],
    [
        "T-053",
        4,
        "Tables: sources/channels, raw_messages(+versions), media, ocr/ai, signals, validation, risk",
        [
            "T-052"
        ],
        [
            "Constraints/unique keys tested"
        ]
    ],
    [
        "T-054",
        4,
        "Tables: commands, acks, orders, positions, trade events, roulette, audit, events",
        [
            "T-052"
        ],
        [
            "Constraints/unique keys tested"
        ]
    ],
    [
        "T-055",
        4,
        "Repository/DAO layer (adapter over vendor where DR specifies)",
        [
            "T-053"
        ],
        [
            "Unit tests >= all CRUD paths"
        ]
    ],
    [
        "T-056",
        4,
        "Crash-recovery test: kill mid-transaction/pipeline and resume",
        [
            "T-055"
        ],
        [
            "Evidence of resume without loss/dup"
        ]
    ],
    [
        "T-057",
        4,
        "Backup/restore + integrity check script",
        [
            "T-055"
        ],
        [
            "Restore equals source"
        ]
    ],
    [
        "T-060",
        5,
        "Settings: api_id/hash/phone/session path; secure storage",
        [
            "T-046"
        ],
        [
            "Secrets never logged; Windows ACL restricted"
        ]
    ],
    [
        "T-061",
        5,
        "Auth flow incl. 2FA",
        [
            "T-060"
        ],
        [
            "REAL login with human credentials or BLOCKED"
        ]
    ],
    [
        "T-062",
        5,
        "Session persistence + restart reuse",
        [
            "T-061"
        ],
        [
            "Restart without re-login (REAL)"
        ]
    ],
    [
        "T-063",
        5,
        "Single-instance lock for one session",
        [
            "T-062"
        ],
        [
            "Second listener refused"
        ]
    ],
    [
        "T-064",
        5,
        "Connect one channel; resolve by id/username/invite",
        [
            "T-062"
        ],
        [
            "REAL read of test channel"
        ]
    ],
    [
        "T-065",
        5,
        "Receive text -> store raw-first",
        [
            "T-064",
            "T-053"
        ],
        [
            "Row exists before any parser call"
        ]
    ],
    [
        "T-066",
        5,
        "Receive images/media (download, hash, size/type validation)",
        [
            "T-065"
        ],
        [
            "Original immutable; corrupt/oversized rejected"
        ]
    ],
    [
        "T-067",
        5,
        "Albums, captions, replies, forwards",
        [
            "T-066"
        ],
        [
            "Fixtures + REAL sample"
        ]
    ],
    [
        "T-068",
        5,
        "Multi-channel with independent states and isolation",
        [
            "T-065"
        ],
        [
            "One channel Error does not stop others"
        ]
    ],
    [
        "T-069",
        5,
        "Edit detection -> new version, delete events",
        [
            "T-065"
        ],
        [
            "Edited message creates version N+1; original retained"
        ]
    ],
    [
        "T-070",
        5,
        "Idempotency (chat,msg,version)",
        [
            "T-065"
        ],
        [
            "Replay 1000 events -> 0 duplicates"
        ]
    ],
    [
        "T-071",
        5,
        "Reconnect with backoff+jitter, error classification",
        [
            "T-064"
        ],
        [
            "Simulated + REAL disconnect logs"
        ]
    ],
    [
        "T-072",
        5,
        "FloodWait handling",
        [
            "T-071"
        ],
        [
            "Injected FloodWaitError waits exact seconds"
        ]
    ],
    [
        "T-073",
        5,
        "Catch-up from last id + recent-edit re-check + periodic reconcile",
        [
            "T-070"
        ],
        [
            "Missed messages stored; no dupes"
        ]
    ],
    [
        "T-074",
        5,
        "Listener as isolated process + heartbeat",
        [
            "T-071"
        ],
        [
            "Engine/listener crash isolation verified"
        ]
    ],
    [
        "T-075",
        5,
        "Per-channel status model & metrics",
        [
            "T-068"
        ],
        [
            "Status transitions logged"
        ]
    ],
    [
        "T-076",
        5,
        "Listener integration test suite (scenarios 1-7, 27, 28)",
        [
            "T-073"
        ],
        [
            "All pass with evidence"
        ]
    ],
    [
        "T-077",
        5,
        "Reports/05_Telegram_Implementation.md",
        [
            "T-076"
        ],
        [
            "Complete"
        ]
    ],
    [
        "T-080",
        6,
        "Signal schema (JSON Schema, versioned) + validator",
        [
            "T-050"
        ],
        [
            "Valid/invalid samples tested"
        ]
    ],
    [
        "T-081",
        6,
        "Labeled message fixture set >=120 (+ Persian/Arabic digits, emoji, negatives)",
        [
            "T-050"
        ],
        [
            "Labels reviewed; stored in tests/fixtures"
        ]
    ],
    [
        "T-082",
        6,
        "Adapter around Fluent parser (vendor+patch) -> schema",
        [
            "T-045",
            "T-080"
        ],
        [
            "Fixture results recorded"
        ]
    ],
    [
        "T-083",
        6,
        "Adapter around forex-gold parser -> schema",
        [
            "T-080"
        ],
        [
            "Fixture results recorded"
        ]
    ],
    [
        "T-084",
        6,
        "Parser comparison report -> DR for selection/combination",
        [
            "T-082",
            "T-083"
        ],
        [
            "Precision/recall per class numbers"
        ]
    ],
    [
        "T-085",
        6,
        "Intent classifier (13 classes)",
        [
            "T-084"
        ],
        [
            "Per-class precision/recall; ambiguous -> review"
        ]
    ],
    [
        "T-086",
        6,
        "Message clustering into signal IDs",
        [
            "T-085"
        ],
        [
            "Multi-message fixtures produce one signal"
        ]
    ],
    [
        "T-087",
        6,
        "Update handling: entry/SL/TP change, BE, partial, close, cancel",
        [
            "T-086"
        ],
        [
            "Fixtures + persisted state transitions"
        ]
    ],
    [
        "T-088",
        6,
        "Symbol alias/broker suffix normalization",
        [
            "T-080"
        ],
        [
            "Table-driven tests"
        ]
    ],
    [
        "T-089",
        6,
        "Number normalization (locales, Persian digits, separators)",
        [
            "T-080"
        ],
        [
            "Property/table tests"
        ]
    ],
    [
        "T-090",
        6,
        "Known-defect regression tests from §10.2",
        [
            "T-045"
        ],
        [
            "All pass"
        ]
    ],
    [
        "T-091",
        6,
        "Wire listener -> classifier -> parser -> DB (state machine)",
        [
            "T-076",
            "T-087"
        ],
        [
            "E2E replay zero lost messages"
        ]
    ],
    [
        "T-092",
        6,
        "Reports/06_Signal_Extraction.md (Milestone M1 report)",
        [
            "T-091"
        ],
        [
            "Complete; M1 report"
        ]
    ],
    [
        "T-100",
        7,
        "Validation rules engine (§14.1) with machine-readable reasons",
        [
            "T-080"
        ],
        [
            "One test per rule + combinations"
        ]
    ],
    [
        "T-101",
        7,
        "Broker symbol spec provider (interface; MT5 + fake)",
        [
            "T-100"
        ],
        [
            "Contract tests on both"
        ]
    ],
    [
        "T-102",
        7,
        "Duplicate/expiry/contradiction checks",
        [
            "T-100"
        ],
        [
            "Fixtures pass"
        ]
    ],
    [
        "T-103",
        7,
        "Confidence thresholds + manual review queue",
        [
            "T-100"
        ],
        [
            "Low-confidence never reaches risk"
        ]
    ],
    [
        "T-104",
        7,
        "Risk config model (global/account/channelxaccount/trade hierarchy)",
        [
            "T-046"
        ],
        [
            "Lower level cannot exceed global"
        ]
    ],
    [
        "T-105",
        7,
        "Position sizing formula doc + implementation",
        [
            "T-101",
            "T-104"
        ],
        [
            ">=25 table-driven cases verified"
        ]
    ],
    [
        "T-106",
        7,
        "Lot rounding/min/max/step, margin check",
        [
            "T-105"
        ],
        [
            "Edge-case tests"
        ]
    ],
    [
        "T-107",
        7,
        "Daily loss / drawdown / exposure / open-orders limits",
        [
            "T-104"
        ],
        [
            "Limit hit blocks new trades"
        ]
    ],
    [
        "T-108",
        7,
        "Multi-TP volume split, partial-close plan (no invented TPs)",
        [
            "T-105"
        ],
        [
            "Tests incl. 1,2,3 TPs"
        ]
    ],
    [
        "T-109",
        7,
        "Roulette state model (per accountxchannel) + persistence",
        [
            "T-054",
            "T-104"
        ],
        [
            "Restart keeps state"
        ]
    ],
    [
        "T-110",
        7,
        "Roulette progression, reset, hard caps, manual reset",
        [
            "T-109"
        ],
        [
            "Deterministic tests; cap hit stops trading + notifies"
        ]
    ],
    [
        "T-111",
        7,
        "Outcome classification from final realized results",
        [
            "T-109"
        ],
        [
            "Partial-close/BE cases correct"
        ]
    ],
    [
        "T-112",
        7,
        "Prove AI/parser output cannot bypass Risk",
        [
            "T-104"
        ],
        [
            "Static+runtime test"
        ]
    ],
    [
        "T-113",
        7,
        "Reports 08, 09, 10",
        [
            "T-110"
        ],
        [
            "Complete"
        ]
    ],
    [
        "T-120",
        8,
        "Image labeled dataset >=80 (real + synthetic flagged) with JSON ground truth",
        [
            "T-066"
        ],
        [
            "Dataset README + ground truth"
        ]
    ],
    [
        "T-121",
        8,
        "Image validation & limits (magic bytes, dims, bomb guard)",
        [
            "T-066"
        ],
        [
            "Malicious/corrupt samples rejected"
        ]
    ],
    [
        "T-122",
        8,
        "Preprocessing pipeline (derived images retained)",
        [
            "T-121"
        ],
        [
            "Before/after samples saved"
        ]
    ],
    [
        "T-123",
        8,
        "OCR engine adapter + number/symbol extraction",
        [
            "T-029",
            "T-122"
        ],
        [
            "Per-field accuracy on dataset"
        ]
    ],
    [
        "T-124",
        8,
        "Chart geometry: line/zone detection, axis calibration, pixel<->price",
        [
            "T-122"
        ],
        [
            "Fit error reported; unreadable flagged unverified"
        ]
    ],
    [
        "T-125",
        8,
        "Vision provider interface + schema-validated output",
        [
            "T-080"
        ],
        [
            "Invalid output rejected"
        ]
    ],
    [
        "T-126",
        8,
        "Adapters: Gemini, OpenRouter, Cloudflare, Ollama, OpenAI-compatible",
        [
            "T-125"
        ],
        [
            "Mock tests pass; REAL when key supplied"
        ]
    ],
    [
        "T-127",
        8,
        "Prompt-injection defense (image text = data) + tests",
        [
            "T-125"
        ],
        [
            "Injection fixtures cannot alter schema/decisions"
        ]
    ],
    [
        "T-128",
        8,
        "Quota/cache/rate-limit manager",
        [
            "T-125"
        ],
        [
            "Exhaustion -> local OCR + review"
        ]
    ],
    [
        "T-129",
        8,
        "Candidate fusion (OCR, Vision, caption, geometry) + disagreement recording",
        [
            "T-123",
            "T-124",
            "T-125"
        ],
        [
            "Disagreement -> review"
        ]
    ],
    [
        "T-130",
        8,
        "Confidence model + calibration on dataset",
        [
            "T-129"
        ],
        [
            "Reliability table; thresholds justified"
        ]
    ],
    [
        "T-131",
        8,
        "Image pipeline worker (bounded concurrency, non-blocking)",
        [
            "T-129"
        ],
        [
            "Listener latency unaffected"
        ]
    ],
    [
        "T-132",
        8,
        "Dataset benchmark run + Reports/07_Vision_AI.md",
        [
            "T-130"
        ],
        [
            "Measured numbers in report"
        ]
    ],
    [
        "T-133",
        8,
        "Image-scenarios 8,9,14,15,16,17,18,25,26 of §16",
        [
            "T-131"
        ],
        [
            "All pass"
        ]
    ],
    [
        "T-140",
        9,
        "DR: forex-gold EA bridge vs MetaTrader5 Python API vs hybrid",
        [
            "T-026",
            "T-030"
        ],
        [
            "DR with protocol evidence"
        ]
    ],
    [
        "T-141",
        9,
        "Execution command schema (command_id, idempotency key, magic, signal_id)",
        [
            "T-054"
        ],
        [
            "Schema tests"
        ]
    ],
    [
        "T-142",
        9,
        "Durable command queue (persist-before-send)",
        [
            "T-141"
        ],
        [
            "Kill during send -> no loss/dup"
        ]
    ],
    [
        "T-143",
        9,
        "MT5 adapter: connect, account info, DEMO-account assertion",
        [
            "T-140"
        ],
        [
            "REAL demo connect; real account refused"
        ]
    ],
    [
        "T-144",
        9,
        "Symbol mapping + live quotes/spread",
        [
            "T-143"
        ],
        [
            "Real symbols resolved"
        ]
    ],
    [
        "T-145",
        9,
        "Market + pending orders with SL/TP",
        [
            "T-143"
        ],
        [
            "REAL demo orders verified"
        ]
    ],
    [
        "T-146",
        9,
        "Ack handling + post-send verification of order/position",
        [
            "T-145"
        ],
        [
            "Unverified never EXECUTED"
        ]
    ],
    [
        "T-147",
        9,
        "Duplicate-execution protection",
        [
            "T-142",
            "T-146"
        ],
        [
            "Replay test -> one position"
        ]
    ],
    [
        "T-148",
        9,
        "Modify SL/TP, break-even, trailing, partial close",
        [
            "T-145"
        ],
        [
            "REAL demo verification each"
        ]
    ],
    [
        "T-149",
        9,
        "Close by signal/channel/account/all-managed; foreign untouched",
        [
            "T-148"
        ],
        [
            "Manual foreign position untouched"
        ]
    ],
    [
        "T-150",
        9,
        "Position monitor + trade-result recording",
        [
            "T-146"
        ],
        [
            "Realized PnL matches terminal history"
        ]
    ],
    [
        "T-151",
        9,
        "Connection monitor + reconnect + disconnect-during-send",
        [
            "T-143"
        ],
        [
            "Scenarios 20-22 pass"
        ]
    ],
    [
        "T-152",
        9,
        "Real-trading hard gate tests",
        [
            "T-143"
        ],
        [
            "No path to real orders"
        ]
    ],
    [
        "T-153",
        9,
        "E2E: text signal -> validation -> risk -> MT5 DEMO order -> close (Milestone M2)",
        [
            "T-147",
            "T-148",
            "T-149",
            "T-150"
        ],
        [
            "Milestone M2 report"
        ]
    ],
    [
        "T-160",
        10,
        "DR + app shell bound to 127.0.0.1",
        [
            "T-030"
        ],
        [
            "Not reachable from LAN"
        ]
    ],
    [
        "T-161",
        10,
        "Overview page (real data, data-state labels)",
        [
            "T-160"
        ],
        [
            "No fabricated values"
        ]
    ],
    [
        "T-162",
        10,
        "Telegram sources page (auth, channels, status, start/stop)",
        [
            "T-077"
        ],
        [
            "Real controls tested"
        ]
    ],
    [
        "T-163",
        10,
        "Live feed + signal inbox",
        [
            "T-091"
        ],
        [
            "Matches DB"
        ]
    ],
    [
        "T-164",
        10,
        "Signal review + image analysis",
        [
            "T-129"
        ],
        [
            "Approve/reject changes pipeline state"
        ]
    ],
    [
        "T-165",
        10,
        "AI settings (secure key entry, test connection, quota)",
        [
            "T-128"
        ],
        [
            "Key never echoed/logged"
        ]
    ],
    [
        "T-166",
        10,
        "Accounts + risk + roulette pages (per channelxaccount)",
        [
            "T-110"
        ],
        [
            "Edits validated & persisted"
        ]
    ],
    [
        "T-167",
        10,
        "MT5 + trade management pages",
        [
            "T-150"
        ],
        [
            "Actions limited to managed trades"
        ]
    ],
    [
        "T-168",
        10,
        "Reports & journal (§15 metrics)",
        [
            "T-050"
        ],
        [
            "Numbers reconcile to DB"
        ]
    ],
    [
        "T-169",
        10,
        "System health/logs page",
        [
            "T-160"
        ],
        [
            "Shows heartbeat ages"
        ]
    ],
    [
        "T-170",
        10,
        "API input validation + auth for remote flag",
        [
            "T-160"
        ],
        [
            "Fuzz/negative tests"
        ]
    ],
    [
        "T-171",
        10,
        "Dashboard E2E tests",
        [
            "T-169"
        ],
        [
            "Pass in CI-like run"
        ]
    ],
    [
        "T-180",
        11,
        "Heartbeat framework for all components",
        [
            "T-074"
        ],
        [
            "Missing heartbeat -> alert"
        ]
    ],
    [
        "T-181",
        11,
        "Queue-depth and stale-signal monitors",
        [
            "T-142"
        ],
        [
            "Thresholds tested"
        ]
    ],
    [
        "T-182",
        11,
        "Watchdog with duplicate-safe recovery",
        [
            "T-147"
        ],
        [
            "Chaos test no duplicate orders"
        ]
    ],
    [
        "T-183",
        11,
        "Graceful shutdown/startup sequencing",
        [
            "T-182"
        ],
        [
            "Documented + tested"
        ]
    ],
    [
        "T-184",
        11,
        "Alerts (dashboard + optional Telegram self-message)",
        [
            "T-180"
        ],
        [
            "Alert fires and clears"
        ]
    ],
    [
        "T-190",
        12,
        "Wire text path end-to-end under supervisor",
        [
            "T-153",
            "T-184"
        ],
        [
            "Scenario replay on DEMO"
        ]
    ],
    [
        "T-191",
        12,
        "Wire image path end-to-end",
        [
            "T-133",
            "T-190"
        ],
        [
            "Chart image -> reviewed -> DEMO order"
        ]
    ],
    [
        "T-192",
        12,
        "Lifecycle audit-trail check: Message->Result",
        [
            "T-190"
        ],
        [
            "Full chain for 20 random trades"
        ]
    ],
    [
        "T-193",
        12,
        "Run the full §16 scenario list (all 28)",
        [
            "T-191"
        ],
        [
            "Pass/Fail table with evidence"
        ]
    ],
    [
        "T-194",
        12,
        "Regression suite (all prior tests) green",
        [
            "T-193"
        ],
        [
            "Single command, saved output"
        ]
    ],
    [
        "T-200",
        13,
        "Secret scan of repo, reports, logs, DB dumps",
        [
            "T-194"
        ],
        [
            "Zero findings"
        ]
    ],
    [
        "T-201",
        13,
        "Session/credential storage review; file ACLs",
        [
            "T-200"
        ],
        [
            "All critical fixed"
        ]
    ],
    [
        "T-202",
        13,
        "Network exposure review (ports, bind addresses)",
        [
            "T-200"
        ],
        [
            "netstat evidence"
        ]
    ],
    [
        "T-203",
        13,
        "Upload/image handling & resource-limit review",
        [
            "T-121"
        ],
        [
            "Fuzz results"
        ]
    ],
    [
        "T-204",
        13,
        "Dependency audit (pip-audit) + license check",
        [
            "T-043"
        ],
        [
            "No unresolved critical vuln"
        ]
    ],
    [
        "T-205",
        13,
        "Resource measurement (CPU/RAM idle, load)",
        [
            "T-194"
        ],
        [
            "Within §17 budget or documented"
        ]
    ],
    [
        "T-206",
        13,
        "24 h soak test (DEMO)",
        [
            "T-194"
        ],
        [
            "Memory/handle chart; no crashes/gaps"
        ]
    ],
    [
        "T-207",
        13,
        "Reports 13, 15",
        [
            "T-206"
        ],
        [
            "Complete"
        ]
    ],
    [
        "T-210",
        14,
        "Install guide + config templates + first-run wizard",
        [
            "T-194"
        ],
        [
            "Fresh user test via README"
        ]
    ],
    [
        "T-211",
        14,
        "Start/stop scripts, optional Task Scheduler/service wrapper",
        [
            "T-183"
        ],
        [
            "Auto-start after reboot verified"
        ]
    ],
    [
        "T-212",
        14,
        "Restart/recovery test on real Windows reboot",
        [
            "T-211"
        ],
        [
            "State resumes; no dupes"
        ]
    ],
    [
        "T-213",
        14,
        "Backup/restore drill",
        [
            "T-057"
        ],
        [
            "Restored system passes smoke test"
        ]
    ],
    [
        "T-214",
        14,
        "Packaging evaluation (venv zip vs installer) - DR",
        [
            "T-210"
        ],
        [
            "Recommendation with trade-offs"
        ]
    ],
    [
        "T-215",
        14,
        "Release package (no secrets, no _src, no venv)",
        [
            "T-200"
        ],
        [
            "Secret scan clean"
        ]
    ],
    [
        "T-216",
        14,
        "Report 16",
        [
            "T-215"
        ],
        [
            "Complete"
        ]
    ],
    [
        "T-220",
        15,
        "Verify every checklist entry has evidence; re-run random 20% of tests",
        [],
        [
            "Sample re-run results"
        ]
    ],
    [
        "T-221",
        15,
        "Full automated test run",
        [
            "T-220"
        ],
        [
            "Output saved"
        ]
    ],
    [
        "T-222",
        15,
        "DEMO end-to-end acceptance session (text + image)",
        [
            "T-221"
        ],
        [
            "Logged witness session"
        ]
    ],
    [
        "T-223",
        15,
        "Verify SOURCE_MAPPING hashes again",
        [
            "T-221"
        ],
        [
            "Script output saved"
        ]
    ],
    [
        "T-224",
        15,
        "Verify LICENSE_REGISTRY + notices in package",
        [
            "T-223"
        ],
        [
            "Obligations satisfied"
        ]
    ],
    [
        "T-225",
        15,
        "MISSING.md and honest limitation list",
        [
            "T-221"
        ],
        [
            "Honest gaps listed"
        ]
    ],
    [
        "T-226",
        15,
        "FINAL_ACCEPTANCE.md using §19 categories",
        [
            "T-225"
        ],
        [
            "No unproven claim"
        ]
    ]
]

# Run from extracted folder or standalone to initialize D:\\AutoTrades\\Darkoob
def main() -> None:
    existed = ROOT.exists()
    print(f"Target {ROOT} exists before run: {existed}")

    for rel in [
        "Reports/Tasks",
        "Reports/evidence",
        "DECISIONS",
        "LICENSES",
        "docs",
        "scripts",
        "config",
    ]:
        (ROOT / rel).mkdir(parents=True, exist_ok=True)

    if not (ROOT / ".git").exists():
        subprocess.run(["git", "init"], cwd=ROOT, check=False)

    subprocess.run(["python", "scripts/render_checklist.py"], cwd=ROOT, check=True)
    subprocess.run(["python", "scripts/verify_checklist.py"], cwd=ROOT, check=True)
    subprocess.run(["python", "scripts/secret_scan.py", "--self-test"], cwd=ROOT, check=True)

    shutil.make_archive(str(ZIP_OUT.with_suffix("")), "zip", root_dir=ROOT)
    print(f"Done! Verified Phase 0 workspace at {ROOT} and zip at {ZIP_OUT}")


if __name__ == "__main__":
    main()
