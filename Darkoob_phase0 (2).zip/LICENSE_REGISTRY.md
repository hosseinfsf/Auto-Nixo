# LICENSE_REGISTRY.md

Updated: 2026-11-27T14:04:33.536Z

| Component / Repo | SPDX ID | Obligations & Constraints | Gate G2 |
|---|---|---|---|
| FluentSignalCopier | TBD (read LICENSE in T-021) | Pending read-only inspection of upstream LICENSE file. | PENDING_CLONE |
| forex-gold | TBD (read LICENSE in T-021) | Pending read-only inspection of upstream LICENSE file. | PENDING_CLONE |
| Telethon / Core Deps | MIT / BSD / Apache-2.0 | Preserve copyright notices in LICENSES/ | N/A |
