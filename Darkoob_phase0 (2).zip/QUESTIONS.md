# QUESTIONS.md

## Q-001 — License Gate G2 (Required before T-041 / copying upstream files)
- **Gate:** Gate G2
- **Context:** Primary repos (FluentSignalCopier, forex-gold) are expected to have ShareAlike / NonCommercial / AGPL-3.0 terms (to be verified in T-021 from cloned LICENSE files).
- **Question:** Do you confirm Darkoob is strictly for personal / non-commercial use and approve proceeding under verified license obligations after T-021?
- **Recommended default:** Personal/non-commercial use only; wait for explicit confirmation before copying any vendor code.
- **Status:** OPEN

## Q-002 — External Credentials & Demo Environment Readiness
- **Gate:** Gates T-061 / T-143
- **Context:** Needed at T-061: Telegram api_id, api_hash, personal phone, and a test channel. Needed at T-143: Local MT5 terminal logged into a DEMO account only. Needed at T-126 (optional): Free-tier Vision AI key or local Ollama.
- **Question:** Confirm availability of Telegram developer credentials and an isolated MT5 DEMO account when reaching Phases 5, 8, and 9.
- **Recommended default:** Keep REAL_TRADING=false and ALLOW_REAL_ORDERS=false at all times; supply credentials only into local .env (never committed).
- **Status:** OPEN

## Q-003 — Gate G3 — Live / Real-Money Account Authorization
- **Gate:** Gate G3
- **Context:** By default Darkoob enforces DEMO_MODE=true, REAL_TRADING=false, ALLOW_REAL_ORDERS=false, and GATE_G3_APPROVED=false (plus InpAllowLiveAccount=false in MQL5 EA). Live accounts can only run after Phase 9–15 Demo soak tests pass and all 4 flags are explicitly switched.
- **Question:** After completing Demo verification, do you explicitly authorize Gate G3 to allow switching to a LIVE MT5 account in .env?
- **Recommended default:** Keep OPEN / DEMO-only until 24h Demo soak test and §16 Scenarios pass without errors.
- **Status:** OPEN
