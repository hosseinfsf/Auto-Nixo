from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class HeartbeatMonitor:
    stale_after_seconds: float = 30.0
    last_beats: dict[str, float] = field(default_factory=dict)

    def beat(self, component: str, now: float | None = None) -> None:
        self.last_beats[component] = time.monotonic() if now is None else now

    def stale_components(self, now: float | None = None) -> list[str]:
        ref = time.monotonic() if now is None else now
        return [
            name
            for name, ts in sorted(self.last_beats.items())
            if (ref - ts) > self.stale_after_seconds
        ]
