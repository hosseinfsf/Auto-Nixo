from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True)
class SymbolSpec:
    symbol: str
    pip_size: float
    min_lot: float
    max_lot: float
    lot_step: float
    pip_value_per_lot: float


@dataclass(frozen=True)
class RiskDecision:
    allowed: bool
    reasons: list[str]
    effective_risk_percent: float
    risk_amount_usd: float
    stop_distance_pips: float
    rounded_lot: float


def calculate_position_size(
    *,
    balance: float,
    risk_percent: float,
    side: str,
    entry_price: float,
    stop_loss: float,
    spec: SymbolSpec,
    roulette_multiplier: float = 1.0,
    max_global_risk_percent: float = 5.0,
) -> RiskDecision:
    reasons: list[str] = []
    if balance <= 0:
        reasons.append("INVALID_ACCOUNT_BALANCE")
    if risk_percent <= 0:
        reasons.append("INVALID_RISK_PERCENT")

    effective_risk = round(risk_percent * max(1.0, roulette_multiplier), 4)
    if effective_risk > max_global_risk_percent:
        reasons.append("RISK_EXCEEDS_GLOBAL_CAP")

    if side == "BUY" and stop_loss >= entry_price:
        reasons.append("SL_NOT_BELOW_ENTRY_FOR_BUY")
    if side == "SELL" and stop_loss <= entry_price:
        reasons.append("SL_NOT_ABOVE_ENTRY_FOR_SELL")

    stop_pips = abs(entry_price - stop_loss) / spec.pip_size
    if stop_pips <= 0:
        reasons.append("ZERO_STOP_DISTANCE")

    risk_usd = (balance * effective_risk) / 100.0
    raw_lot = risk_usd / (stop_pips * spec.pip_value_per_lot) if stop_pips > 0 else 0.0
    stepped = math.floor(raw_lot / spec.lot_step) * spec.lot_step
    rounded_lot = round(min(spec.max_lot, max(0.0, stepped)), 2)

    if rounded_lot < spec.min_lot:
        reasons.append("LOT_BELOW_BROKER_MIN")

    return RiskDecision(
        allowed=len(reasons) == 0,
        reasons=reasons,
        effective_risk_percent=effective_risk,
        risk_amount_usd=round(risk_usd, 2),
        stop_distance_pips=round(stop_pips, 1),
        rounded_lot=rounded_lot,
    )
