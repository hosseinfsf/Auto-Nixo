from __future__ import annotations

import re
from dataclasses import dataclass, field

PERSIAN_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٫،\u200c\u200e\u200f", "0123456789..   ")
ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")

_BOUNDARY_L = r"(?:^|[\s:,(#|@])"
_BOUNDARY_R = r"(?=$|[\s:),!?.|/\r\n])"

SYMBOL_ALIASES: list[tuple[re.Pattern[str], str]] = [
    (re.compile(_BOUNDARY_L + r"(XAUUSD(?:\.[a-z0-9]+)?|XAU/USD|GOLD|طلا|انس(?:\s*جهانی)?|اونس)" + _BOUNDARY_R, re.IGNORECASE), "XAUUSD"),
    (re.compile(_BOUNDARY_L + r"(XAGUSD(?:\.[a-z0-9]+)?|XAG/USD|SILVER|نقره)" + _BOUNDARY_R, re.IGNORECASE), "XAGUSD"),
    (re.compile(_BOUNDARY_L + r"(EURUSD(?:\.[a-z0-9]+)?|EUR/USD)" + _BOUNDARY_R, re.IGNORECASE), "EURUSD"),
    (re.compile(_BOUNDARY_L + r"(GBPUSD(?:\.[a-z0-9]+)?|GBP/USD)" + _BOUNDARY_R, re.IGNORECASE), "GBPUSD"),
    (re.compile(_BOUNDARY_L + r"(USDJPY(?:\.[a-z0-9]+)?|USD/JPY)" + _BOUNDARY_R, re.IGNORECASE), "USDJPY"),
    (re.compile(_BOUNDARY_L + r"(USDCHF(?:\.[a-z0-9]+)?|USD/CHF)" + _BOUNDARY_R, re.IGNORECASE), "USDCHF"),
    (re.compile(_BOUNDARY_L + r"(USDCAD(?:\.[a-z0-9]+)?|USD/CAD)" + _BOUNDARY_R, re.IGNORECASE), "USDCAD"),
    (re.compile(_BOUNDARY_L + r"(AUDUSD(?:\.[a-z0-9]+)?|AUD/USD)" + _BOUNDARY_R, re.IGNORECASE), "AUDUSD"),
    (re.compile(_BOUNDARY_L + r"(NZDUSD(?:\.[a-z0-9]+)?|NZD/USD)" + _BOUNDARY_R, re.IGNORECASE), "NZDUSD"),
    (re.compile(_BOUNDARY_L + r"(EURJPY(?:\.[a-z0-9]+)?|EUR/JPY)" + _BOUNDARY_R, re.IGNORECASE), "EURJPY"),
    (re.compile(_BOUNDARY_L + r"(GBPJPY(?:\.[a-z0-9]+)?|GBP/JPY)" + _BOUNDARY_R, re.IGNORECASE), "GBPJPY"),
    (re.compile(_BOUNDARY_L + r"(US30(?:\.[a-z0-9]+)?|DJ30|DOWJONES|DOW)" + _BOUNDARY_R, re.IGNORECASE), "US30"),
    (re.compile(_BOUNDARY_L + r"(NAS100(?:\.[a-z0-9]+)?|USTEC(?:\.[a-z0-9]+)?|US100|NDX|NASDAQ)" + _BOUNDARY_R, re.IGNORECASE), "NAS100"),
]


@dataclass(frozen=True)
class NormalizedSignal:
    schema_version: str
    intent: str
    symbol_raw: str | None
    symbol: str | None
    side: str | None
    order_type: str | None
    entries: list[float]
    stop_loss: float | None
    take_profits: list[float]
    validation_passed: bool
    validation_reasons: list[str] = field(default_factory=list)


def normalize_digits_and_separators(text: str) -> str:
    cleaned = text.translate(PERSIAN_DIGITS).translate(ARABIC_DIGITS)
    cleaned = re.sub(r"(\d),(?=\d{3}(?:\D|$))", r"\1", cleaned)
    return re.sub(r"[ \t]+", " ", cleaned)


def normalize_symbol(text: str) -> tuple[str | None, str | None]:
    for rx, canonical in SYMBOL_ALIASES:
        match = rx.search(text)
        if match:
            return match.group(1), canonical
    return None, None


def _extract_take_profits(text: str) -> list[float]:
    tps: list[float] = []
    block_rx = re.compile(
        r"(?:tps?\s*\d*|take\s*profits?\s*\d*|تارگت(?:\s*ها)?\s*\d*|حد\s*سود\s*\d*)\s*[:=]?\s*(\d+(?:\.\d+)?(?:\s*[/,\-–|]\s*\d+(?:\.\d+)?)*)",
        re.IGNORECASE,
    )
    for block in block_rx.finditer(text):
        for raw_num in re.findall(r"\d+(?:\.\d+)?", block.group(1)):
            val = float(raw_num)
            if val not in tps:
                tps.append(val)
    return tps


def parse_and_validate_signal(raw_text: str) -> NormalizedSignal:
    text = normalize_digits_and_separators(raw_text).strip()
    lower = text.lower()
    symbol_raw, symbol = normalize_symbol(text)

    if re.search(
        r"(?:^|[\s:,(])(move\s*sl\s*to\s*be|sl\s*to\s*(?:be|entry)|breakeven|break\s*even|risk\s*free|ریسک\s*فری|فری\s*ریسک|استاپ\s*(?:به|روی)\s*(?:نقطه\s*)?ورود)(?=$|[\s:),!?.])",
        text,
        re.IGNORECASE,
    ):
        return NormalizedSignal("1.0", "MOVE_BE", symbol_raw, symbol, None, None, [], None, [], True, [])
    if re.search(
        r"(?:^|[\s:,(])(partial\s*close|close\s*half|close\s*50%|book\s*partial|secure\s*(?:half|profit)|سیو\s*سود|بستن\s*نصف|پارشال)(?=$|[\s:),!?.])",
        text,
        re.IGNORECASE,
    ):
        return NormalizedSignal("1.0", "PARTIAL_CLOSE", symbol_raw, symbol, None, None, [], None, [], True, [])
    if re.search(
        r"(?:^|[\s:,(])(close\s*all|close\s*now|close\s*(?:trade|position)|exit\s*now|بستن\s*کامل|خروج\s*کامل|معامله\s*را\s*ببندید)(?=$|[\s:),!?.])",
        text,
        re.IGNORECASE,
    ):
        return NormalizedSignal("1.0", "CLOSE_SIGNAL", symbol_raw, symbol, None, None, [], None, [], True, [])
    if re.search(
        r"(?:^|[\s:,(])(cancel\s*(?:order|pending)|delete\s*(?:pending|order)|remove\s*order|لغو\s*سفارش|کنسل\s*سفارش)(?=$|[\s:),!?.])",
        text,
        re.IGNORECASE,
    ):
        return NormalizedSignal("1.0", "CANCEL_PENDING", symbol_raw, symbol, None, None, [], None, [], True, [])

    has_buy = bool(re.search(r"(?:^|[\s:,(#|])(buy|long|خرید)(?=$|[\s:),!?.])", text, re.IGNORECASE))
    has_sell = bool(re.search(r"(?:^|[\s:,(#|])(sell|short|فروش)(?=$|[\s:),!?.])", text, re.IGNORECASE))

    if not has_buy and not has_sell:
        if re.search(
            r"(?:^|[\s:,(])((?:update|move|change|modify|adjust|set|new)\s+(?:sl|stop\s*loss)|(?:تغییر|اصلاح|آپدیت|جابجایی)\s*(?:حد\s*ضرر|استاپ))(?=$|[\s:),!?.])",
            text,
            re.IGNORECASE,
        ):
            upd_sl_m = re.search(r"(?:sl|stop\s*loss|حد\s*ضرر|استاپ)\s*(?:to|به)?\s*[:=]?\s*(\d+(?:\.\d+)?)", text, re.IGNORECASE)
            upd_sl = float(upd_sl_m.group(1)) if upd_sl_m else None
            upd_reasons = [] if upd_sl is not None else ["MISSING_STOP_LOSS"]
            return NormalizedSignal("1.0", "UPDATE_SL", symbol_raw, symbol, None, None, [], upd_sl, [], len(upd_reasons) == 0, upd_reasons)

        if re.search(
            r"(?:^|[\s:,(])((?:update|move|change|modify|adjust|set|new)\s+(?:tps?|take\s*profits?)|(?:تغییر|اصلاح|آپدیت|جابجایی)\s*(?:تارگت(?:\s*ها)?|حد\s*سود))(?=$|[\s:),!?.])",
            text,
            re.IGNORECASE,
        ):
            cleaned_tp_text = re.sub(r"(?:^|\s)(?:to|به)(?=\s)", ":", text, flags=re.IGNORECASE)
            upd_tps = _extract_take_profits(cleaned_tp_text)
            upd_reasons = [] if upd_tps else ["MISSING_TAKE_PROFIT"]
            return NormalizedSignal("1.0", "UPDATE_TP", symbol_raw, symbol, None, None, [], None, upd_tps, len(upd_reasons) == 0, upd_reasons)

        return NormalizedSignal("1.0", "NON_SIGNAL_CHATTER", symbol_raw, symbol, None, None, [], None, [], False, ["NO_TRADE_DIRECTION_FOUND"])

    reasons: list[str] = []
    if has_buy and has_sell:
        reasons.append("CONTRADICTORY_DIRECTION_BUY_AND_SELL")

    side = "BUY" if has_buy and not has_sell else "SELL" if has_sell and not has_buy else None
    if re.search(r"\b(?:limit|لیمیت)\b", lower) or "لیمیت" in text:
        order_type = "LIMIT"
    elif re.search(r"(?:buy|sell)\s+stop\b|\bstop\s+order\b", lower) or "استاپ اردر" in text:
        order_type = "STOP"
    else:
        order_type = "MARKET"

    entries: list[float] = []
    range_match = re.search(
        r"(?:entry(?:\s+zone)?|enter|zone|@|at|ورود|محدوده\s*ورود|(?:buy|sell|long|short|خرید|فروش)(?:[ \t]+(?:now|instant|market|limit|stop|zone|around|near|above|below|at|@|فوری|مارکت|لیمیت|استاپ|در\s*محدوده)){0,3})[ \t]*[:=(]?[ \t]*(\d+(?:\.\d+)?)[ \t]*(?:-|to|–|تا)[ \t]*(\d+(?:\.\d+)?)",
        text,
        re.IGNORECASE,
    )
    if range_match:
        entries = [float(range_match.group(1)), float(range_match.group(2))]
    else:
        single_match = re.search(
            r"(?:entry(?:\s+price)?|enter|@|at|ورود|قیمت\s*ورود|(?:buy|sell|long|short|خرید|فروش)(?:[ \t]+(?:now|instant|market|limit|stop|around|near|at|@|فوری|مارکت|لیمیت|استاپ)){0,3})[ \t]*[:=(]?[ \t]*(\d+(?:\.\d+)?)",
            text,
            re.IGNORECASE,
        )
        if single_match:
            entries = [float(single_match.group(1))]

    sl_match = re.search(r"(?:sl|stop\s*loss|حد\s*ضرر|استاپ(?:\s*لاس)?)\s*[:=]?\s*(\d+(?:\.\d+)?)", text, re.IGNORECASE)
    stop_loss = float(sl_match.group(1)) if sl_match else None

    take_profits = _extract_take_profits(text)

    if not symbol:
        reasons.append("UNKNOWN_OR_MISSING_SYMBOL")
    if not entries:
        reasons.append("MISSING_ENTRY_PRICE")
    if stop_loss is None:
        reasons.append("MISSING_STOP_LOSS")
    if not take_profits:
        reasons.append("MISSING_TAKE_PROFIT")

    if side and entries and stop_loss is not None:
        ref = entries[0]
        if side == "BUY" and stop_loss >= ref:
            reasons.append("INVALID_SL_GE_ENTRY_FOR_BUY")
        if side == "SELL" and stop_loss <= ref:
            reasons.append("INVALID_SL_LE_ENTRY_FOR_SELL")
        for tp in take_profits:
            if side == "BUY" and tp <= ref:
                reasons.append("INVALID_TP_LE_ENTRY_FOR_BUY")
                break
            if side == "SELL" and tp >= ref:
                reasons.append("INVALID_TP_GE_ENTRY_FOR_SELL")
                break

    intent = "AMBIGUOUS_REVIEW" if "CONTRADICTORY_DIRECTION_BUY_AND_SELL" in reasons else "NEW_SIGNAL"
    return NormalizedSignal(
        schema_version="1.0",
        intent=intent,
        symbol_raw=symbol_raw,
        symbol=symbol,
        side=side,
        order_type=order_type,
        entries=entries,
        stop_loss=stop_loss,
        take_profits=take_profits,
        validation_passed=len(reasons) == 0,
        validation_reasons=reasons,
    )
