from __future__ import annotations

import sqlite3
from pathlib import Path


SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA busy_timeout=5000;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS raw_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    msg_id INTEGER NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    event_type TEXT NOT NULL DEFAULT 'NEW',
    text TEXT NOT NULL,
    reply_to_msg_id INTEGER,
    media_path TEXT,
    media_sha256 TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(chat_id, msg_id, version)
);

CREATE TABLE IF NOT EXISTS channel_cursors (
    chat_id INTEGER PRIMARY KEY,
    last_msg_id INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS message_deletions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    msg_id INTEGER NOT NULL,
    deleted_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS execution_commands (
    command_id TEXT PRIMARY KEY,
    idempotency_key TEXT NOT NULL UNIQUE,
    signal_id TEXT NOT NULL,
    account_login INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    lot REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDING',
    mt5_ticket INTEGER,
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS roulette_states (
    channel_account_key TEXT PRIMARY KEY,
    step INTEGER NOT NULL DEFAULT 0,
    consecutive_losses INTEGER NOT NULL DEFAULT 0,
    halted INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""


class DarkoobStorage:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path

    def _connect(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.db_path, timeout=5.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA busy_timeout=5000;")
        return conn

    def init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(SCHEMA_SQL)

    def insert_raw_message(
        self,
        *,
        chat_id: int,
        msg_id: int,
        version: int,
        text: str,
        event_type: str = "NEW",
        reply_to_msg_id: int | None = None,
        media_path: str | None = None,
        media_sha256: str | None = None,
    ) -> bool:
        with self._connect() as conn:
            cur = conn.execute(
                """
                INSERT OR IGNORE INTO raw_messages
                (chat_id, msg_id, version, event_type, text, reply_to_msg_id, media_path, media_sha256)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (chat_id, msg_id, version, event_type, text, reply_to_msg_id, media_path, media_sha256),
            )
            return cur.rowcount == 1

    def get_next_message_version(self, chat_id: int, msg_id: int) -> int:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT COALESCE(MAX(version), 0) AS max_v FROM raw_messages WHERE chat_id = ? AND msg_id = ?",
                (chat_id, msg_id),
            ).fetchone()
            return int(row["max_v"]) + 1 if row else 1

    def record_message_deletion(self, chat_id: int, msg_id: int) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO message_deletions (chat_id, msg_id) VALUES (?, ?)",
                (chat_id, msg_id),
            )

    def get_last_msg_id(self, chat_id: int) -> int:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT last_msg_id FROM channel_cursors WHERE chat_id = ?",
                (chat_id,),
            ).fetchone()
            return int(row["last_msg_id"]) if row else 0

    def update_last_msg_id(self, chat_id: int, msg_id: int) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO channel_cursors (chat_id, last_msg_id, updated_at)
                VALUES (?, ?, datetime('now'))
                ON CONFLICT(chat_id) DO UPDATE SET
                    last_msg_id = MAX(channel_cursors.last_msg_id, excluded.last_msg_id),
                    updated_at = datetime('now')
                """,
                (chat_id, msg_id),
            )

    def enqueue_execution_command(
        self,
        *,
        command_id: str,
        idempotency_key: str,
        signal_id: str,
        account_login: int,
        symbol: str,
        side: str,
        lot: float,
        status: str = "PENDING",
    ) -> bool:
        with self._connect() as conn:
            cur = conn.execute(
                """
                INSERT OR IGNORE INTO execution_commands
                (command_id, idempotency_key, signal_id, account_login, symbol, side, lot, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (command_id, idempotency_key, signal_id, account_login, symbol, side, lot, status),
            )
            return cur.rowcount == 1

    def get_execution_command(self, idempotency_key: str) -> dict | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM execution_commands WHERE idempotency_key = ?",
                (idempotency_key,),
            ).fetchone()
            return dict(row) if row else None

    def update_execution_status(
        self,
        command_id: str,
        *,
        status: str,
        mt5_ticket: int | None = None,
        error_message: str | None = None,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE execution_commands
                SET status = ?,
                    mt5_ticket = COALESCE(?, mt5_ticket),
                    error_message = ?,
                    updated_at = datetime('now')
                WHERE command_id = ?
                """,
                (status, mt5_ticket, error_message, command_id),
            )

    def get_roulette_row(self, key: str) -> tuple[int, int, bool]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT step, consecutive_losses, halted FROM roulette_states WHERE channel_account_key = ?",
                (key,),
            ).fetchone()
            if not row:
                return 0, 0, False
            return int(row[0]), int(row[1]), bool(row[2])

    def save_roulette_row(self, key: str, *, step: int, consecutive_losses: int, halted: bool) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO roulette_states (channel_account_key, step, consecutive_losses, halted, updated_at)
                VALUES (?, ?, ?, ?, datetime('now'))
                ON CONFLICT(channel_account_key) DO UPDATE SET
                    step=excluded.step,
                    consecutive_losses=excluded.consecutive_losses,
                    halted=excluded.halted,
                    updated_at=datetime('now')
                """,
                (key, step, consecutive_losses, 1 if halted else 0),
            )
