from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from darkoob.storage import DarkoobStorage

ACCOUNT_TRADE_MODE_DEMO = 0
ACCOUNT_TRADE_MODE_CONTEST = 1
ACCOUNT_TRADE_MODE_REAL = 2
TRADE_ACTION_DEAL = 1
TRADE_ACTION_PENDING = 5
TRADE_ACTION_SLTP = 6
ORDER_TYPE_BUY = 0
ORDER_TYPE_SELL = 1
ORDER_TYPE_BUY_LIMIT = 2
ORDER_TYPE_SELL_LIMIT = 3
ORDER_TYPE_BUY_STOP = 4
ORDER_TYPE_SELL_STOP = 5
ORDER_TIME_GTC = 0
ORDER_FILLING_IOC = 1
TRADE_RETCODE_DONE = 10009
TRADE_RETCODE_PLACED = 10008


@dataclass(frozen=True)
class AccountSnapshot:
    login: int
    is_demo: bool
    server: str


def assert_demo_account_only(account: AccountSnapshot) -> None:
    """Hard gate (T-143 / T-152): refuse any non-demo account or live trading flag."""
    if os.getenv("REAL_TRADING", "false").lower() == "true":
        raise PermissionError("REAL_TRADING=true is blocked without Gate G3 authorization.")
    if not account.is_demo:
        raise PermissionError(
            f"Refusing non-demo MT5 account {account.login} on server {account.server}."
        )


def assert_execution_account_allowed(
    account: AccountSnapshot,
    *,
    allow_live: bool = False,
    gate_g3_approved: bool = False,
) -> None:
    """Allow DEMO by default; allow LIVE only when Gate G3 is explicitly authorized."""
    if account.is_demo:
        return
    if allow_live and gate_g3_approved:
        return
    raise PermissionError(
        f"Refusing non-demo MT5 account {account.login} on server {account.server}. "
        "To run on a LIVE account, complete Demo verification and enable Gate G3 "
        "(DEMO_MODE=false, REAL_TRADING=true, ALLOW_REAL_ORDERS=true, GATE_G3_APPROVED=true)."
    )


class MT5Backend(Protocol):
    def initialize(
        self,
        *,
        path: str | None = None,
        login: int | None = None,
        password: str | None = None,
        server: str | None = None,
    ) -> bool: ...
    def shutdown(self) -> None: ...
    def account_info(self) -> dict | None: ...
    def symbol_info(self, symbol: str) -> dict | None: ...
    def symbol_select(self, symbol: str, enable: bool = True) -> bool: ...
    def symbol_info_tick(self, symbol: str) -> dict | None: ...
    def order_send(self, request: dict) -> dict: ...
    def positions_get(self, symbol: str | None = None, ticket: int | None = None) -> list[dict]: ...
    def orders_get(self, symbol: str | None = None, ticket: int | None = None) -> list[dict]: ...
    def last_error(self) -> tuple[int, str]: ...


class RealMT5Backend:
    """Lazy wrapper around Windows MetaTrader5 Python IPC package."""

    def __init__(self) -> None:
        try:
            import MetaTrader5 as mt5  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "MetaTrader5 package is required on Windows to connect to a live terminal."
            ) from exc
        self._mt5 = mt5

    def initialize(
        self,
        *,
        path: str | None = None,
        login: int | None = None,
        password: str | None = None,
        server: str | None = None,
    ) -> bool:
        kwargs: dict = {}
        if path:
            kwargs["path"] = path
        if login:
            kwargs["login"] = login
        if password:
            kwargs["password"] = password
        if server:
            kwargs["server"] = server
        return bool(self._mt5.initialize(**kwargs))

    def shutdown(self) -> None:
        self._mt5.shutdown()

    def account_info(self) -> dict | None:
        info = self._mt5.account_info()
        return info._asdict() if info is not None else None

    def symbol_info(self, symbol: str) -> dict | None:
        info = self._mt5.symbol_info(symbol)
        return info._asdict() if info is not None else None

    def symbol_select(self, symbol: str, enable: bool = True) -> bool:
        return bool(self._mt5.symbol_select(symbol, enable))

    def symbol_info_tick(self, symbol: str) -> dict | None:
        tick = self._mt5.symbol_info_tick(symbol)
        return tick._asdict() if tick is not None else None

    def order_send(self, request: dict) -> dict:
        res = self._mt5.order_send(request)
        if res is None:
            return {"retcode": -1, "order": 0, "deal": 0, "comment": str(self.last_error())}
        return res._asdict()

    def positions_get(self, symbol: str | None = None, ticket: int | None = None) -> list[dict]:
        if ticket is not None:
            rows = self._mt5.positions_get(ticket=ticket)
        elif symbol:
            rows = self._mt5.positions_get(symbol=symbol)
        else:
            rows = self._mt5.positions_get()
        return [r._asdict() for r in (rows or ())]

    def orders_get(self, symbol: str | None = None, ticket: int | None = None) -> list[dict]:
        if ticket is not None:
            rows = self._mt5.orders_get(ticket=ticket)
        elif symbol:
            rows = self._mt5.orders_get(symbol=symbol)
        else:
            rows = self._mt5.orders_get()
        return [r._asdict() for r in (rows or ())]

    def last_error(self) -> tuple[int, str]:
        code, msg = self._mt5.last_error()
        return (int(code), str(msg))


@dataclass(frozen=True)
class ExecutionRequest:
    command_id: str
    idempotency_key: str
    signal_id: str
    symbol: str
    side: str
    order_type: str
    lot: float
    entry_price: float | None
    stop_loss: float
    take_profit: float | None


@dataclass(frozen=True)
class ExecutionOutcome:
    status: str
    ticket: int | None = None
    detail: str = ""


class MT5DemoExecutor:
    """MT5 execution & reconciliation engine (DEMO by default; LIVE opt-in via Gate G3)."""

    def __init__(
        self,
        backend: MT5Backend,
        *,
        magic_number: int = 202604,
        allow_live: bool = False,
        gate_g3_approved: bool = False,
    ) -> None:
        self.backend = backend
        self.magic_number = magic_number
        self.allow_live = allow_live
        self.gate_g3_approved = gate_g3_approved
        self._account: AccountSnapshot | None = None

    @classmethod
    def from_settings(cls, backend: MT5Backend, settings) -> "MT5DemoExecutor":
        allow_live = (
            (not settings.demo_mode)
            and settings.real_trading
            and settings.allow_real_orders
        )
        return cls(
            backend,
            magic_number=settings.mt5_magic_number,
            allow_live=allow_live,
            gate_g3_approved=getattr(settings, "gate_g3_approved", False),
        )

    def _comment_tag(self, command_id: str) -> str:
        return f"dk:{command_id}"[:31]

    def connect(
        self,
        *,
        terminal_path: str | None = None,
        login: int | None = None,
        password: str | None = None,
        server: str | None = None,
    ) -> AccountSnapshot:
        ok = self.backend.initialize(path=terminal_path, login=login, password=password, server=server)
        if not ok:
            raise RuntimeError(f"MT5 initialize failed: {self.backend.last_error()}")
        info = self.backend.account_info()
        if not info:
            self.backend.shutdown()
            raise RuntimeError("MT5 connected but account_info() returned None.")

        snap = AccountSnapshot(
            login=int(info["login"]),
            is_demo=(int(info["trade_mode"]) == ACCOUNT_TRADE_MODE_DEMO),
            server=str(info.get("server", "")),
        )
        try:
            assert_execution_account_allowed(
                snap,
                allow_live=self.allow_live,
                gate_g3_approved=self.gate_g3_approved,
            )
        except Exception:
            self.backend.shutdown()
            raise
        self._account = snap
        return snap

    def _require_demo_account(self) -> AccountSnapshot:
        if self._account is None:
            raise RuntimeError("MT5DemoExecutor is not connected.")
        assert_execution_account_allowed(
            self._account,
            allow_live=self.allow_live,
            gate_g3_approved=self.gate_g3_approved,
        )
        return self._account

    def reconcile_command(self, command_id: str, symbol: str) -> int | None:
        tag = self._comment_tag(command_id)
        for pos in self.backend.positions_get(symbol=symbol):
            if int(pos.get("magic", 0)) == self.magic_number and str(pos.get("comment", "")) == tag:
                return int(pos["ticket"])
        for order in self.backend.orders_get(symbol=symbol):
            if int(order.get("magic", 0)) == self.magic_number and str(order.get("comment", "")) == tag:
                return int(order["ticket"])
        return None

    def place_order(self, storage: DarkoobStorage, req: ExecutionRequest) -> ExecutionOutcome:
        account = self._require_demo_account()

        existing = storage.get_execution_command(req.idempotency_key)
        if existing and existing["status"] == "EXECUTED" and existing.get("mt5_ticket"):
            return ExecutionOutcome("ALREADY_EXECUTED", int(existing["mt5_ticket"]), "Skipped duplicate idempotency_key")

        reconciled_ticket = self.reconcile_command(req.command_id, req.symbol)
        if reconciled_ticket is not None:
            storage.enqueue_execution_command(
                command_id=req.command_id,
                idempotency_key=req.idempotency_key,
                signal_id=req.signal_id,
                account_login=account.login,
                symbol=req.symbol,
                side=req.side,
                lot=req.lot,
                status="EXECUTED",
            )
            storage.update_execution_status(req.command_id, status="EXECUTED", mt5_ticket=reconciled_ticket)
            return ExecutionOutcome("ALREADY_EXECUTED", reconciled_ticket, "Reconciled pre-existing MT5 position/order")

        if not self.backend.symbol_select(req.symbol, True):
            return ExecutionOutcome("REJECTED", None, f"Symbol not available: {req.symbol}")
        tick = self.backend.symbol_info_tick(req.symbol)
        if not tick:
            return ExecutionOutcome("REJECTED", None, f"Missing live tick for {req.symbol}")

        storage.enqueue_execution_command(
            command_id=req.command_id,
            idempotency_key=req.idempotency_key,
            signal_id=req.signal_id,
            account_login=account.login,
            symbol=req.symbol,
            side=req.side,
            lot=req.lot,
            status="SENT_UNVERIFIED",
        )

        if req.order_type == "MARKET":
            action = TRADE_ACTION_DEAL
            order_type = ORDER_TYPE_BUY if req.side == "BUY" else ORDER_TYPE_SELL
            price = float(tick["ask"]) if req.side == "BUY" else float(tick["bid"])
        elif req.order_type == "LIMIT":
            if req.entry_price is None:
                return ExecutionOutcome("REJECTED", None, "LIMIT order requires entry_price")
            action = TRADE_ACTION_PENDING
            order_type = ORDER_TYPE_BUY_LIMIT if req.side == "BUY" else ORDER_TYPE_SELL_LIMIT
            price = float(req.entry_price)
        else:
            if req.entry_price is None:
                return ExecutionOutcome("REJECTED", None, "STOP order requires entry_price")
            action = TRADE_ACTION_PENDING
            order_type = ORDER_TYPE_BUY_STOP if req.side == "BUY" else ORDER_TYPE_SELL_STOP
            price = float(req.entry_price)

        mt5_req: dict = {
            "action": action,
            "symbol": req.symbol,
            "volume": float(req.lot),
            "type": order_type,
            "price": price,
            "sl": float(req.stop_loss),
            "deviation": 20,
            "magic": self.magic_number,
            "comment": self._comment_tag(req.command_id),
            "type_time": ORDER_TIME_GTC,
            "type_filling": ORDER_FILLING_IOC,
        }
        if req.take_profit is not None:
            mt5_req["tp"] = float(req.take_profit)

        result = self.backend.order_send(mt5_req)
        retcode = int(result.get("retcode", -1))
        if retcode not in (TRADE_RETCODE_DONE, TRADE_RETCODE_PLACED):
            err = f"retcode={retcode}: {result.get('comment', '')}"
            storage.update_execution_status(req.command_id, status="FAILED", error_message=err)
            return ExecutionOutcome("FAILED", None, err)

        # Post-send terminal verification before marking EXECUTED
        verified_ticket = self.reconcile_command(req.command_id, req.symbol) or int(result.get("order", 0))
        if not verified_ticket:
            storage.update_execution_status(req.command_id, status="UNVERIFIED", error_message="Order missing in post-send query")
            return ExecutionOutcome("UNVERIFIED", None, "Order missing in post-send terminal query")

        storage.update_execution_status(req.command_id, status="EXECUTED", mt5_ticket=verified_ticket)
        return ExecutionOutcome("EXECUTED", verified_ticket, "Verified on MT5 DEMO terminal")

    def move_to_breakeven(self, ticket: int) -> ExecutionOutcome:
        self._require_demo_account()
        positions = self.backend.positions_get(ticket=ticket)
        if not positions:
            return ExecutionOutcome("NOT_FOUND", None, f"Position {ticket} not found")
        pos = positions[0]
        if int(pos.get("magic", 0)) != self.magic_number:
            return ExecutionOutcome("REFUSED_FOREIGN", ticket, "Foreign manual trade untouched")

        res = self.backend.order_send({
            "action": TRADE_ACTION_SLTP,
            "position": ticket,
            "symbol": pos["symbol"],
            "sl": float(pos["price_open"]),
            "tp": float(pos.get("tp", 0.0)),
        })
        if int(res.get("retcode", -1)) == TRADE_RETCODE_DONE:
            return ExecutionOutcome("MODIFIED", ticket, "SL moved to breakeven")
        return ExecutionOutcome("FAILED", ticket, str(res.get("comment", "")))

    def partial_close(self, ticket: int, *, fraction: float = 0.5) -> ExecutionOutcome:
        self._require_demo_account()
        positions = self.backend.positions_get(ticket=ticket)
        if not positions:
            return ExecutionOutcome("NOT_FOUND", None, f"Position {ticket} not found")
        pos = positions[0]
        if int(pos.get("magic", 0)) != self.magic_number:
            return ExecutionOutcome("REFUSED_FOREIGN", ticket, "Foreign manual trade untouched")

        close_vol = round(float(pos["volume"]) * fraction, 2)
        if close_vol <= 0:
            return ExecutionOutcome("REJECTED", ticket, "Partial volume rounded to 0")
        tick = self.backend.symbol_info_tick(pos["symbol"])
        if not tick:
            return ExecutionOutcome("FAILED", ticket, "Missing live tick")

        is_buy = int(pos["type"]) == ORDER_TYPE_BUY
        res = self.backend.order_send({
            "action": TRADE_ACTION_DEAL,
            "position": ticket,
            "symbol": pos["symbol"],
            "volume": close_vol,
            "type": ORDER_TYPE_SELL if is_buy else ORDER_TYPE_BUY,
            "price": float(tick["bid"]) if is_buy else float(tick["ask"]),
            "deviation": 20,
            "magic": self.magic_number,
            "comment": "dk:partial",
            "type_filling": ORDER_FILLING_IOC,
        })
        if int(res.get("retcode", -1)) == TRADE_RETCODE_DONE:
            return ExecutionOutcome("PARTIAL_CLOSED", ticket, f"Closed {close_vol} lot")
        return ExecutionOutcome("FAILED", ticket, str(res.get("comment", "")))

    def close_managed_only(self, symbol: str | None = None) -> list[ExecutionOutcome]:
        self._require_demo_account()
        outcomes: list[ExecutionOutcome] = []
        for pos in self.backend.positions_get(symbol=symbol):
            if int(pos.get("magic", 0)) != self.magic_number:
                continue  # Never touch foreign / manual positions
            ticket = int(pos["ticket"])
            tick = self.backend.symbol_info_tick(pos["symbol"])
            if not tick:
                outcomes.append(ExecutionOutcome("FAILED", ticket, "Missing live tick"))
                continue
            is_buy = int(pos["type"]) == ORDER_TYPE_BUY
            res = self.backend.order_send({
                "action": TRADE_ACTION_DEAL,
                "position": ticket,
                "symbol": pos["symbol"],
                "volume": float(pos["volume"]),
                "type": ORDER_TYPE_SELL if is_buy else ORDER_TYPE_BUY,
                "price": float(tick["bid"]) if is_buy else float(tick["ask"]),
                "deviation": 20,
                "magic": self.magic_number,
                "comment": "dk:close_all",
                "type_filling": ORDER_FILLING_IOC,
            })
            status = "CLOSED" if int(res.get("retcode", -1)) == TRADE_RETCODE_DONE else "FAILED"
            outcomes.append(ExecutionOutcome(status, ticket, str(res.get("comment", ""))))
        return outcomes


def export_ea_command_csv(csv_path: Path, req: ExecutionRequest) -> None:
    """Append a command row compatible with mql5/DarkoobBridgeEA.mq5."""
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    action = req.side
    if req.order_type == "LIMIT":
        action = f"{req.side}_LIMIT"
    elif req.order_type == "STOP":
        action = f"{req.side}_STOP"
    price = req.entry_price if req.entry_price is not None else 0.0
    tp = req.take_profit if req.take_profit is not None else 0.0
    row = f"{req.command_id};{action};{req.symbol};{req.lot};{price};{req.stop_loss};{tp}\n"
    with csv_path.open("a", encoding="ascii") as fh:
        fh.write(row)
