from __future__ import annotations

from dataclasses import dataclass

MAX_IMAGE_BYTES = 10 * 1024 * 1024  # 10 MB bomb guard (T-121)


@dataclass(frozen=True)
class ImageValidationResult:
    valid: bool
    detected_format: str | None
    reason: str | None = None


@dataclass(frozen=True)
class CandidateProposal:
    source: str
    side: str
    entry: float
    stop_loss: float


@dataclass(frozen=True)
class FusionDecision:
    agreed: bool
    requires_manual_review: bool
    disagreements: tuple[str, ...]
    selected: CandidateProposal | None


def validate_image_bytes(payload: bytes) -> ImageValidationResult:
    if len(payload) > MAX_IMAGE_BYTES:
        return ImageValidationResult(False, None, "IMAGE_EXCEEDS_MAX_BYTES")
    if payload.startswith(b"\x89PNG\r\n\x1a\n"):
        return ImageValidationResult(True, "PNG")
    if payload.startswith(b"\xff\xd8\xff"):
        return ImageValidationResult(True, "JPEG")
    if payload.startswith(b"RIFF") and payload[8:12] == b"WEBP":
        return ImageValidationResult(True, "WEBP")
    return ImageValidationResult(False, None, "INVALID_IMAGE_MAGIC_BYTES")


def fuse_candidates(candidates: list[CandidateProposal], *, max_price_delta_pct: float = 0.005) -> FusionDecision:
    if not candidates:
        return FusionDecision(False, True, ("NO_CANDIDATES",), None)

    disagreements: list[str] = []
    sides = {c.side for c in candidates}
    if len(sides) > 1:
        disagreements.append("SIDE_DISAGREEMENT")

    entries = [c.entry for c in candidates]
    if max(entries) > 0 and ((max(entries) - min(entries)) / max(entries)) > max_price_delta_pct:
        disagreements.append("ENTRY_PRICE_DISAGREEMENT")

    sls = [c.stop_loss for c in candidates]
    if max(sls) > 0 and ((max(sls) - min(sls)) / max(sls)) > max_price_delta_pct:
        disagreements.append("STOP_LOSS_DISAGREEMENT")

    agreed = len(disagreements) == 0
    return FusionDecision(
        agreed=agreed,
        requires_manual_review=not agreed,
        disagreements=tuple(disagreements),
        selected=candidates[0] if agreed else None,
    )
