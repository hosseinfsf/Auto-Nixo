from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from typing import Mapping

REDACT_PATTERNS = [
    re.compile(r"(?i)(api_hash\s*[:=]\s*['\"]?)[0-9a-f]{32}(['\"]?)"),
    re.compile(r"sk-(?:or-v1-)?[A-Za-z0-9_-]{20,}"),
    re.compile(r"AIza[0-9A-Za-z\-_]{35}"),
    re.compile(r"1[A-Za-z0-9_-]{80,}={0,2}"),
]


def redact_secrets(message: str) -> str:
    out = message
    out = REDACT_PATTERNS[0].sub(r"\1***REDACTED***\2", out)
    for rx in REDACT_PATTERNS[1:]:
        out = rx.sub("***REDACTED***", out)
    return out


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = redact_secrets(record.msg)
        return True


@dataclass(frozen=True)
class DarkoobSettings:
    demo_mode: bool
    dry_run: bool
    real_trading: bool
    allow_real_orders: bool
    gate_g3_approved: bool
    dashboard_host: str
    dashboard_port: int
    max_global_risk_percent: float
    mt5_magic_number: int
    telegram_channels: tuple[str, ...]
    roulette_enabled: bool = True
    roulette_mode: str = "WIN_LOSS_STEP"
    roulette_risk_increment: float = 0.5
    roulette_multiplier: float = 1.5
    roulette_max_steps: int = 5
    roulette_max_risk_cap: float = 4.0

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "DarkoobSettings":
        src = env if env is not None else os.environ
        host = src.get("DASHBOARD_HOST", "127.0.0.1").strip()
        if host != "127.0.0.1":
            raise ValueError("DASHBOARD_HOST must remain 127.0.0.1 unless remote auth is enabled (T-160).")
        raw_channels = src.get("TELEGRAM_CHANNELS", "")
        channels = tuple(ch.strip() for ch in raw_channels.split(",") if ch.strip())
        return cls(
            demo_mode=src.get("DEMO_MODE", "true").lower() == "true",
            dry_run=src.get("DRY_RUN", "true").lower() == "true",
            real_trading=src.get("REAL_TRADING", "false").lower() == "true",
            allow_real_orders=src.get("ALLOW_REAL_ORDERS", "false").lower() == "true",
            gate_g3_approved=src.get("GATE_G3_APPROVED", "false").lower() == "true",
            dashboard_host=host,
            dashboard_port=int(src.get("DASHBOARD_PORT", "8080")),
            max_global_risk_percent=float(src.get("MAX_GLOBAL_RISK_PERCENT", "5.0")),
            mt5_magic_number=int(src.get("MT5_MAGIC_NUMBER", "202604")),
            telegram_channels=channels,
            roulette_enabled=src.get("ROULETTE_ENABLED", "true").lower() == "true",
            roulette_mode=src.get("ROULETTE_MODE", "WIN_LOSS_STEP").strip().upper(),
            roulette_risk_increment=float(src.get("ROULETTE_RISK_INCREMENT", "0.5")),
            roulette_multiplier=float(src.get("ROULETTE_MULTIPLIER", "1.5")),
            roulette_max_steps=int(src.get("ROULETTE_MAX_STEPS", "5")),
            roulette_max_risk_cap=float(src.get("ROULETTE_MAX_RISK_CAP", "4.0")),
        )
