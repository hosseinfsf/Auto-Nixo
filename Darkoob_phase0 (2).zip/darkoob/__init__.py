"""Darkoob core deterministic package (Phase 6-7 modules)."""
