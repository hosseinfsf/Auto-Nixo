from __future__ import annotations

import json
import sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from darkoob.config import DarkoobSettings


def create_handler(db_path: Path):
    class DarkoobHandler(BaseHTTPRequestHandler):
        def _send_json(self, status: int, payload: dict) -> None:
            body = json.dumps(payload).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            if self.path == "/health":
                self._send_json(200, {"status": "ok", "bind": "127.0.0.1", "demo_only": True})
                return
            if self.path == "/stats":
                if not db_path.exists():
                    self._send_json(200, {"raw_messages": 0, "execution_commands": 0})
                    return
                with sqlite3.connect(db_path) as conn:
                    raw_cnt = conn.execute("SELECT COUNT(*) FROM raw_messages").fetchone()[0]
                    cmd_cnt = conn.execute("SELECT COUNT(*) FROM execution_commands").fetchone()[0]
                self._send_json(200, {"raw_messages": raw_cnt, "execution_commands": cmd_cnt})
                return
            self._send_json(404, {"error": "not_found"})

        def log_message(self, format: str, *args) -> None:
            return

    return DarkoobHandler


def serve_localhost(db_path: Path = Path("data/darkoob.db")) -> None:
    settings = DarkoobSettings.from_env()
    server = HTTPServer((settings.dashboard_host, settings.dashboard_port), create_handler(db_path))
    print(f"Darkoob local API bound strictly to http://{settings.dashboard_host}:{settings.dashboard_port}")
    server.serve_forever()


if __name__ == "__main__":
    serve_localhost()
