from __future__ import annotations

import asyncio
import hashlib
import os
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Awaitable, Callable, Mapping

from darkoob.image_fusion import validate_image_bytes
from darkoob.storage import DarkoobStorage


class SessionLock:
    """Single-instance lock preventing concurrent Telethon access to one session (T-063)."""

    def __init__(self, lock_path: Path) -> None:
        self.lock_path = lock_path
        self._acquired = False

    def __enter__(self) -> "SessionLock":
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(str(self.lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode("ascii"))
            os.close(fd)
            self._acquired = True
        except FileExistsError as exc:
            raise RuntimeError(f"Session lock already held at {self.lock_path}") from exc
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._acquired and self.lock_path.exists():
            self.lock_path.unlink()
            self._acquired = False


def compute_reconnect_delay(attempt: int, *, base: float = 2.0, cap: float = 60.0) -> float:
    """Exponential backoff with bounded jitter for Telethon reconnects (T-071)."""
    exp = min(cap, base * (2 ** max(0, attempt)))
    return round(exp + random.uniform(0.0, 1.0), 3)


@dataclass(frozen=True)
class TelegramConfig:
    api_id: int
    api_hash: str
    phone: str
    session_path: Path
    channels: tuple[str | int, ...]
    media_dir: Path
    password: str | None = None
    catchup_limit: int = 100

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "TelegramConfig":
        src = env if env is not None else os.environ
        raw_channels = src.get("TELEGRAM_CHANNELS", "")
        parsed_channels: list[str | int] = []
        for item in raw_channels.split(","):
            val = item.strip()
            if not val:
                continue
            parsed_channels.append(int(val) if val.lstrip("-").isdigit() else val)
        return cls(
            api_id=int(src.get("TELEGRAM_API_ID", "0") or "0"),
            api_hash=src.get("TELEGRAM_API_HASH", "").strip(),
            phone=src.get("TELEGRAM_PHONE", "").strip(),
            session_path=Path(src.get("TELEGRAM_SESSION_PATH", "data/telegram.session")),
            channels=tuple(parsed_channels),
            media_dir=Path(src.get("TELEGRAM_MEDIA_DIR", "data/media")),
            password=src.get("TELEGRAM_2FA_PASSWORD") or None,
        )


@dataclass(frozen=True)
class IncomingTelegramEvent:
    chat_id: int
    msg_id: int
    version: int
    event_type: str
    text: str
    reply_to_msg_id: int | None = None
    media_path: str | None = None
    media_sha256: str | None = None


class DarkoobTelegramRunner:
    """Raw-first Telethon capture with edit versioning, FloodWait, and catch-up (T-060..T-076)."""

    def __init__(
        self,
        config: TelegramConfig,
        storage: DarkoobStorage,
        *,
        client: Any | None = None,
        on_event: Callable[[IncomingTelegramEvent], Awaitable[None]] | None = None,
    ) -> None:
        self.config = config
        self.storage = storage
        self.client = client
        self.on_event = on_event
        self._lock: SessionLock | None = None
        self.resolved_entities: dict[str | int, Any] = {}

    async def connect(self) -> Any:
        if self.config.api_id <= 0 or len(self.config.api_hash) != 32:
            raise ValueError("Valid TELEGRAM_API_ID and 32-char TELEGRAM_API_HASH are required.")

        lock_path = self.config.session_path.with_suffix(".lock")
        self._lock = SessionLock(lock_path)
        self._lock.__enter__()

        if self.client is None:
            try:
                from telethon import TelegramClient  # type: ignore
                from telethon.errors import SessionPasswordNeededError  # type: ignore
            except ImportError as exc:
                self.close_lock()
                raise RuntimeError("Telethon package is required for live Telegram connectivity.") from exc

            self.config.session_path.parent.mkdir(parents=True, exist_ok=True)
            client = TelegramClient(str(self.config.session_path), self.config.api_id, self.config.api_hash)
            await client.connect()
            if not await client.is_user_authorized():
                await client.send_code_request(self.config.phone)
                try:
                    code = input("Enter Telegram verification code: ").strip()
                    await client.sign_in(self.config.phone, code)
                except SessionPasswordNeededError:
                    if not self.config.password:
                        raise RuntimeError("Telegram 2FA enabled; set TELEGRAM_2FA_PASSWORD.")
                    await client.sign_in(password=self.config.password)
            self.client = client

        return self.client

    def close_lock(self) -> None:
        if self._lock is not None:
            self._lock.__exit__(None, None, None)
            self._lock = None

    async def resolve_channels(self) -> dict[str | int, Any]:
        if self.client is None:
            raise RuntimeError("Telegram client not initialized.")
        for ch in self.config.channels:
            try:
                self.resolved_entities[ch] = await self.client.get_entity(ch)
            except Exception:
                # Per-channel isolation: log/skip unresolved channel without halting others
                continue
        return self.resolved_entities

    def _save_validated_media(self, chat_id: int, msg_id: int, payload: bytes) -> tuple[str | None, str | None]:
        validation = validate_image_bytes(payload)
        if not validation.valid or not validation.detected_format:
            return None, None
        digest = hashlib.sha256(payload).hexdigest()
        ext = validation.detected_format.lower()
        target = self.config.media_dir / f"{chat_id}_{msg_id}_{digest[:12]}.{ext}"
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_bytes(payload)
        return str(target), digest

    async def handle_new_message(
        self,
        chat_id: int,
        msg_id: int,
        text: str,
        *,
        reply_to_msg_id: int | None = None,
        media_bytes: bytes | None = None,
    ) -> IncomingTelegramEvent | None:
        media_path, media_sha256 = (
            self._save_validated_media(chat_id, msg_id, media_bytes)
            if media_bytes is not None
            else (None, None)
        )
        inserted = self.storage.insert_raw_message(
            chat_id=chat_id,
            msg_id=msg_id,
            version=1,
            event_type="NEW",
            text=text,
            reply_to_msg_id=reply_to_msg_id,
            media_path=media_path,
            media_sha256=media_sha256,
        )
        self.storage.update_last_msg_id(chat_id, msg_id)
        if not inserted:
            return None
        ev = IncomingTelegramEvent(
            chat_id=chat_id,
            msg_id=msg_id,
            version=1,
            event_type="NEW",
            text=text,
            reply_to_msg_id=reply_to_msg_id,
            media_path=media_path,
            media_sha256=media_sha256,
        )
        if self.on_event is not None:
            await self.on_event(ev)
        return ev

    async def handle_edited_message(
        self,
        chat_id: int,
        msg_id: int,
        text: str,
        *,
        reply_to_msg_id: int | None = None,
    ) -> IncomingTelegramEvent | None:
        next_ver = self.storage.get_next_message_version(chat_id, msg_id)
        inserted = self.storage.insert_raw_message(
            chat_id=chat_id,
            msg_id=msg_id,
            version=next_ver,
            event_type="EDIT",
            text=text,
            reply_to_msg_id=reply_to_msg_id,
        )
        if not inserted:
            return None
        ev = IncomingTelegramEvent(
            chat_id=chat_id,
            msg_id=msg_id,
            version=next_ver,
            event_type="EDIT",
            text=text,
            reply_to_msg_id=reply_to_msg_id,
        )
        if self.on_event is not None:
            await self.on_event(ev)
        return ev

    async def handle_deleted_messages(self, chat_id: int, msg_ids: list[int]) -> None:
        for mid in msg_ids:
            self.storage.record_message_deletion(chat_id, int(mid))

    async def catch_up_channel(self, chat_id_or_entity: Any) -> list[IncomingTelegramEvent]:
        if self.client is None:
            raise RuntimeError("Telegram client not initialized.")
        entity = await self.client.get_entity(chat_id_or_entity)
        chat_id = int(getattr(entity, "id", chat_id_or_entity))
        last_id = self.storage.get_last_msg_id(chat_id)
        captured: list[IncomingTelegramEvent] = []
        async for msg in self.client.iter_messages(
            entity,
            min_id=last_id,
            limit=self.config.catchup_limit,
            reverse=True,
        ):
            ev = await self.handle_new_message(
                chat_id=chat_id,
                msg_id=int(msg.id),
                text=str(getattr(msg, "raw_text", "") or ""),
                reply_to_msg_id=getattr(msg, "reply_to_msg_id", None),
            )
            if ev is not None:
                captured.append(ev)
        return captured

    async def run_with_floodwait(
        self,
        op: Callable[[], Awaitable[Any]],
        *,
        max_retries: int = 5,
        sleep_fn: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> Any:
        attempt = 0
        while True:
            try:
                return await op()
            except Exception as exc:
                attempt += 1
                if attempt > max_retries:
                    raise
                flood_secs = getattr(exc, "seconds", None)
                if flood_secs is not None:
                    await sleep_fn(float(flood_secs))
                else:
                    await sleep_fn(compute_reconnect_delay(attempt))

    async def start_listening(self) -> None:
        client = await self.connect()
        await self.resolve_channels()
        for entity in self.resolved_entities.values():
            await self.catch_up_channel(entity)

        from telethon import events  # type: ignore

        targets = list(self.resolved_entities.values())

        @client.on(events.NewMessage(chats=targets))
        async def _on_new(event) -> None:
            media_bytes = await event.download_media(file=bytes) if event.media else None
            await self.handle_new_message(
                chat_id=int(event.chat_id),
                msg_id=int(event.id),
                text=str(event.raw_text or ""),
                reply_to_msg_id=getattr(event.message, "reply_to_msg_id", None),
                media_bytes=media_bytes,
            )

        @client.on(events.MessageEdited(chats=targets))
        async def _on_edit(event) -> None:
            await self.handle_edited_message(
                chat_id=int(event.chat_id),
                msg_id=int(event.id),
                text=str(event.raw_text or ""),
                reply_to_msg_id=getattr(event.message, "reply_to_msg_id", None),
            )

        @client.on(events.MessageDeleted(chats=targets))
        async def _on_delete(event) -> None:
            if event.chat_id is not None:
                await self.handle_deleted_messages(int(event.chat_id), list(event.deleted_ids))

        await self.run_with_floodwait(client.run_until_disconnected)
