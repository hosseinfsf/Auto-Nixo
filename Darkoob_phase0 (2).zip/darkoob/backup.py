from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class BackupDrillResult:
    integrity_ok: bool
    restored_raw_count: int


def backup_and_verify(source_db: Path, backup_db: Path) -> BackupDrillResult:
    """Online SQLite backup + PRAGMA integrity_check verification (T-057 / T-213)."""
    backup_db.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(source_db) as src, sqlite3.connect(backup_db) as dst:
        src.backup(dst)

    with sqlite3.connect(backup_db) as check_conn:
        integrity = check_conn.execute("PRAGMA integrity_check;").fetchone()[0]
        cnt = check_conn.execute("SELECT COUNT(*) FROM raw_messages;").fetchone()[0]

    return BackupDrillResult(integrity_ok=(integrity == "ok"), restored_raw_count=int(cnt))
