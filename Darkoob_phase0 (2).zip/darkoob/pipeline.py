from __future__ import annotations

import hashlib
from dataclasses import dataclass
from darkoob.mt5_guard import AccountSnapshot, assert_execution_account_allowed
from darkoob.normalization import parse_and_validate_signal
from darkoob.risk_engine import SymbolSpec, calculate_position_size
from darkoob.roulette import PersistentRoulette, RouletteConfig, RouletteSnapshot
from darkoob.storage import DarkoobStorage
from darkoob.vision_guard import sanitize_untrusted_image_text

MANAGEMENT_INTENTS = {
    "MOVE_BE",
    "PARTIAL_CLOSE",
    "CLOSE_SIGNAL",
    "CANCEL_PENDING",
    "UPDATE_SL",
    "UPDATE_TP",
}


@dataclass(frozen=True)
class PipelineResult:
    status: str
    intent: str = ""
    lot: float | None = None
    reasons: tuple[str, ...] = ()
    roulette_step: int = 0
    effective_risk_percent: float | None = None


def _default_roulette_config(
    *,
    chat_id: int,
    account_login: int,
    risk_percent: float,
    roulette_enabled: bool = True,
) -> RouletteConfig:
    return RouletteConfig(
        channel_account_key=f"{chat_id}:{account_login}",
        enabled=roulette_enabled,
        mode="WIN_LOSS_STEP",
        base_risk_percent=risk_percent,
        risk_increment=0.5,
        multiplier=1.5,
        max_steps=5,
        max_risk_percent_cap=4.0,
    )


def record_pipeline_trade_outcome(
    *,
    storage: DarkoobStorage,
    chat_id: int,
    account_login: int,
    net_profit: float,
    risk_percent: float = 1.0,
    roulette_enabled: bool = True,
    roulette_config: RouletteConfig | None = None,
) -> RouletteSnapshot:
    cfg = roulette_config or _default_roulette_config(
        chat_id=chat_id,
        account_login=account_login,
        risk_percent=risk_percent,
        roulette_enabled=roulette_enabled,
    )
    return PersistentRoulette(storage, cfg).record_net_result(net_profit)


def process_incoming_message(
    *,
    storage: DarkoobStorage,
    account: AccountSnapshot,
    spec: SymbolSpec,
    chat_id: int,
    msg_id: int,
    version: int,
    raw_text: str,
    balance: float,
    risk_percent: float,
    allow_live: bool = False,
    gate_g3_approved: bool = False,
    roulette_enabled: bool = True,
    roulette_config: RouletteConfig | None = None,
) -> PipelineResult:
    assert_execution_account_allowed(
        account,
        allow_live=allow_live,
        gate_g3_approved=gate_g3_approved,
    )

    # 1. Raw-first idempotent persistence (Phase 4 & 5)
    inserted = storage.insert_raw_message(chat_id=chat_id, msg_id=msg_id, version=version, text=raw_text)
    if not inserted:
        return PipelineResult(status="DUPLICATE_EVENT_IGNORED")

    # 2. Untrusted text prompt-injection check (Phase 8)
    guard = sanitize_untrusted_image_text(raw_text)
    if guard.injection_detected:
        return PipelineResult(status="MANUAL_REVIEW_REQUIRED", reasons=tuple(guard.matched_rules))

    # 3. Deterministic normalization & §14.1 validation (Phase 6)
    sig = parse_and_validate_signal(raw_text)

    if sig.intent in MANAGEMENT_INTENTS:
        if not sig.validation_passed:
            return PipelineResult(status="VALIDATION_REJECTED", intent=sig.intent, reasons=tuple(sig.validation_reasons))
        idem_key = f"{chat_id}:{msg_id}:v{version}:{account.login}"
        cmd_id = hashlib.sha256(idem_key.encode("utf-8")).hexdigest()[:16]
        queued = storage.enqueue_execution_command(
            command_id=cmd_id,
            idempotency_key=idem_key,
            signal_id=f"sig_{chat_id}_{msg_id}",
            account_login=account.login,
            symbol=sig.symbol or spec.symbol,
            side=sig.intent,
            lot=0.0,
        )
        if not queued:
            return PipelineResult(status="DUPLICATE_COMMAND_IGNORED", intent=sig.intent)
        return PipelineResult(status="QUEUED_MANAGEMENT_FOR_DEMO", intent=sig.intent, lot=0.0)

    if not sig.validation_passed or not sig.side or not sig.entries or sig.stop_loss is None:
        return PipelineResult(status="VALIDATION_REJECTED", intent=sig.intent, reasons=tuple(sig.validation_reasons))

    # 4. Roulette + Non-bypassable Risk Gate (Phase 7, Roulette active by default)
    rlt_cfg = roulette_config or _default_roulette_config(
        chat_id=chat_id,
        account_login=account.login,
        risk_percent=risk_percent,
        roulette_enabled=roulette_enabled,
    )
    rlt_snap = PersistentRoulette(storage, rlt_cfg).load()
    if rlt_snap.halted:
        return PipelineResult(
            status="ROULETTE_HALTED",
            intent=sig.intent,
            reasons=("ROULETTE_HALTED",),
            roulette_step=rlt_snap.step,
            effective_risk_percent=rlt_snap.effective_risk_percent,
        )

    risk = calculate_position_size(
        balance=balance,
        risk_percent=risk_percent,
        side=sig.side,
        entry_price=sig.entries[0],
        stop_loss=sig.stop_loss,
        spec=spec,
        roulette_multiplier=rlt_snap.multiplier_value,
        max_global_risk_percent=max(5.0, rlt_cfg.max_risk_percent_cap),
    )
    if not risk.allowed:
        return PipelineResult(
            status="RISK_REJECTED",
            intent=sig.intent,
            reasons=tuple(risk.reasons),
            roulette_step=rlt_snap.step,
            effective_risk_percent=risk.effective_risk_percent,
        )

    # 5. Persist-before-send execution command queue (Phase 9)
    idem_key = f"{chat_id}:{msg_id}:v{version}:{account.login}"
    cmd_id = hashlib.sha256(idem_key.encode("utf-8")).hexdigest()[:16]
    queued = storage.enqueue_execution_command(
        command_id=cmd_id,
        idempotency_key=idem_key,
        signal_id=f"sig_{chat_id}_{msg_id}",
        account_login=account.login,
        symbol=sig.symbol or spec.symbol,
        side=sig.side,
        lot=risk.rounded_lot,
    )
    if not queued:
        return PipelineResult(status="DUPLICATE_COMMAND_IGNORED", intent=sig.intent)
    return PipelineResult(
        status="QUEUED_FOR_DEMO",
        intent=sig.intent,
        lot=risk.rounded_lot,
        roulette_step=rlt_snap.step,
        effective_risk_percent=risk.effective_risk_percent,
    )
