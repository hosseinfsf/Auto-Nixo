from __future__ import annotations

from dataclasses import dataclass
from darkoob.storage import DarkoobStorage

VALID_ROULETTE_MODES = (
    "WIN_LOSS_STEP",
    "CLASSIC",
    "REVERSE",
    "PAROLI",
    "FIXED_INCREMENT",
    "MULTIPLIER",
)


@dataclass(frozen=True)
class RouletteConfig:
    channel_account_key: str
    enabled: bool = True
    mode: str = "WIN_LOSS_STEP"
    base_risk_percent: float = 1.0
    risk_increment: float = 0.5
    multiplier: float = 1.5
    max_steps: int = 5
    max_risk_percent_cap: float = 4.0


@dataclass(frozen=True)
class RouletteSnapshot:
    step: int
    consecutive_losses: int
    halted: bool
    multiplier_value: float
    effective_risk_percent: float = 1.0
    mode: str = "WIN_LOSS_STEP"
    enabled: bool = True


class PersistentRoulette:
    def __init__(self, storage: DarkoobStorage, config: RouletteConfig) -> None:
        self.storage = storage
        self.config = config
        self.mode = config.mode.strip().upper() if config.mode else "WIN_LOSS_STEP"
        if self.mode not in VALID_ROULETTE_MODES:
            self.mode = "WIN_LOSS_STEP"

    def _uncapped_risk(self, step: int) -> float:
        if step <= 0:
            return self.config.base_risk_percent
        if self.mode in ("PAROLI", "MULTIPLIER") or (self.mode == "REVERSE" and self.config.risk_increment <= 0):
            return self.config.base_risk_percent * (max(1.0, self.config.multiplier) ** step)
        return self.config.base_risk_percent + step * max(0.0, self.config.risk_increment)

    def _effective_risk(self, step: int) -> float:
        if not self.config.enabled or step <= 0:
            return round(min(self.config.max_risk_percent_cap, self.config.base_risk_percent), 4)
        return round(min(self.config.max_risk_percent_cap, max(0.01, self._uncapped_risk(step))), 4)

    def load(self) -> RouletteSnapshot:
        if not self.config.enabled:
            eff = self._effective_risk(0)
            return RouletteSnapshot(
                step=0,
                consecutive_losses=0,
                halted=False,
                multiplier_value=1.0,
                effective_risk_percent=eff,
                mode=self.mode,
                enabled=False,
            )
        step, losses, halted = self.storage.get_roulette_row(self.config.channel_account_key)
        eff = self._effective_risk(step)
        mult = round(eff / self.config.base_risk_percent, 4) if self.config.base_risk_percent > 0 else 1.0
        return RouletteSnapshot(
            step=step,
            consecutive_losses=losses,
            halted=halted,
            multiplier_value=mult,
            effective_risk_percent=eff,
            mode=self.mode,
            enabled=True,
        )

    def record_outcome(self, outcome: str) -> RouletteSnapshot:
        cur = self.load()
        norm = outcome.strip().upper()
        if norm == "RESET":
            self.storage.save_roulette_row(self.config.channel_account_key, step=0, consecutive_losses=0, halted=False)
            return self.load()
        if not self.config.enabled or cur.halted:
            return cur
        if norm == "BE":
            return cur

        if self.mode == "WIN_LOSS_STEP":
            if norm == "WIN":
                cand = cur.step + 1
                next_step = cand if (cand <= self.config.max_steps and self._uncapped_risk(cand) <= self.config.max_risk_percent_cap) else cur.step
                self.storage.save_roulette_row(self.config.channel_account_key, step=next_step, consecutive_losses=0, halted=False)
            elif norm == "LOSS":
                next_step = max(0, cur.step - 1)
                self.storage.save_roulette_row(self.config.channel_account_key, step=next_step, consecutive_losses=cur.consecutive_losses + 1, halted=False)
        elif self.mode in ("CLASSIC", "FIXED_INCREMENT", "MULTIPLIER"):
            if norm == "WIN":
                cand = cur.step + 1
                next_step = cand if (cand <= self.config.max_steps and self._uncapped_risk(cand) <= self.config.max_risk_percent_cap) else cur.step
                self.storage.save_roulette_row(self.config.channel_account_key, step=next_step, consecutive_losses=0, halted=False)
            elif norm == "LOSS":
                self.storage.save_roulette_row(self.config.channel_account_key, step=0, consecutive_losses=cur.consecutive_losses + 1, halted=False)
        elif self.mode == "PAROLI":
            if norm == "WIN":
                cand = cur.step + 1
                next_step = 0 if (cand > self.config.max_steps or self._uncapped_risk(cand) > self.config.max_risk_percent_cap) else cand
                self.storage.save_roulette_row(self.config.channel_account_key, step=next_step, consecutive_losses=0, halted=False)
            elif norm == "LOSS":
                self.storage.save_roulette_row(self.config.channel_account_key, step=0, consecutive_losses=cur.consecutive_losses + 1, halted=False)
        elif self.mode == "REVERSE":
            if norm == "WIN":
                self.storage.save_roulette_row(self.config.channel_account_key, step=0, consecutive_losses=0, halted=False)
            elif norm == "LOSS":
                next_losses = cur.consecutive_losses + 1
                if cur.step + 1 > self.config.max_steps:
                    self.storage.save_roulette_row(self.config.channel_account_key, step=cur.step, consecutive_losses=next_losses, halted=True)
                else:
                    candidate = self._uncapped_risk(cur.step + 1)
                    if candidate > self.config.max_risk_percent_cap:
                        self.storage.save_roulette_row(self.config.channel_account_key, step=cur.step, consecutive_losses=next_losses, halted=True)
                    else:
                        self.storage.save_roulette_row(self.config.channel_account_key, step=cur.step + 1, consecutive_losses=next_losses, halted=False)

        return self.load()

    def record_net_result(self, net_profit: float) -> RouletteSnapshot:
        if net_profit > 1e-9:
            return self.record_outcome("WIN")
        if net_profit < -1e-9:
            return self.record_outcome("LOSS")
        return self.record_outcome("BE")
