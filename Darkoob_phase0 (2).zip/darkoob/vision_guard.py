from __future__ import annotations

import re
from dataclasses import dataclass

INJECTION_PATTERNS = [
    re.compile(r"ignore\s+previous\s+instructions", re.IGNORECASE),
    re.compile(r"bypass\s+risk", re.IGNORECASE),
    re.compile(r"override\s+(?:lot|risk|sl|stop)", re.IGNORECASE),
    re.compile(r"system\s+prompt", re.IGNORECASE),
]


@dataclass(frozen=True)
class VisionGuardResult:
    injection_detected: bool
    matched_rules: list[str]
    requires_manual_review: bool


def sanitize_untrusted_image_text(ocr_or_caption_text: str) -> VisionGuardResult:
    hits = [rx.pattern for rx in INJECTION_PATTERNS if rx.search(ocr_or_caption_text)]
    return VisionGuardResult(
        injection_detected=len(hits) > 0,
        matched_rules=hits,
        requires_manual_review=len(hits) > 0,
    )
