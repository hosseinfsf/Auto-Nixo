# SOURCE_MAPPING.md

Updated: 2026-11-27T14:04:33.536Z

| Repository | Read-Only Mirror | Commit Hash | SPDX License | Gate G2 Status |
|---|---|---|---|---|
| FluentSignalCopier | `_src/FluentSignalCopier` | `PENDING_CLONE` | TBD (read LICENSE in T-021) | PENDING_CLONE |
| forex-gold | `_src/forex-gold` | `PENDING_CLONE` | TBD (read LICENSE in T-021) | PENDING_CLONE |

## Integrity Rules
- `_src/` is strictly read-only after cloning (`T-020`).
- No files may be copied into `vendor/` until `T-022` (Gate G2) is explicitly `APPROVED_G2`.
- Every copied vendor file must record matching source and destination SHA-256 checksums here (`T-041`).
