# 00_Project_Overview — Darkoob

- **Target Path:** `D:\AutoTrades\Darkoob`
- **OS / Runtime:** Windows 11, Python 3.12 (no GPU required)
- **Milestones:**
  - M1 — Safe Reader (Phases 0–6)
  - M2 — Validated Demo Execution (Phases 7–11 text path, Phase 9 MT5 Demo)
  - M3 — Image Intelligence (Phase 8: OCR + Chart Geometry + Optional Vision AI)
  - M4 — Full Dashboard, Roulette, Reports (Phases 10–12)
  - M5 — Hardening, Security, Windows Deployment, Acceptance (Phases 13–15)
- **Key Risks:**
  - Upstream license constraints (verify CC BY-NC-SA 4.0 / AGPL-3.0 in Gate G2 before copying files).
  - Prompt injection & false positives in chart images (mitigated via strict schema + manual review queue).
  - Duplicate execution after crash/reconnect (mitigated via raw-first DB, idempotency keys, persist-before-send queue).
