# DR-007 — Operator Dashboard (Phase 10)

- **Status:** PROPOSED
- **Selected Option:** FastAPI (127.0.0.1) + React/Vite UI

## Evaluated Options
### Option 1: FastAPI (127.0.0.1) + React/Vite UI
- **Pros:** Strict localhost binding, typed API validation, clean real-time DB views.
- **Cons:** Separate build step for frontend.

### Option 2: Server-rendered Jinja Templates
- **Pros:** Single process.
- **Cons:** Less responsive for live feed and signal review.

## Rationale
Matches local-first security posture (never bound to 0.0.0.0 without explicit auth flag).
