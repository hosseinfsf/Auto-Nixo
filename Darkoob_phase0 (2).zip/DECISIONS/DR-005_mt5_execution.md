# DR-005 — MT5 Execution Bridge (Phase 9)

- **Status:** PROPOSED
- **Selected Option:** MetaTrader5 Python API + Persist-Before-Send Queue

## Evaluated Options
### Option 1: MetaTrader5 Python API + Persist-Before-Send Queue
- **Pros:** Direct terminal verification, no extra EA socket lag, strict DEMO assertion.
- **Cons:** Windows-only MT5 terminal requirement.

### Option 2: forex-gold MQL5 EA File/Socket Bridge
- **Pros:** Works cross-process via EA.
- **Cons:** Requires maintaining MQL5 EA protocol parity (verify in T-026).

## Rationale
Subject to T-026 protocol audit; persist-before-send idempotency prevents duplicate positions on reconnect.
