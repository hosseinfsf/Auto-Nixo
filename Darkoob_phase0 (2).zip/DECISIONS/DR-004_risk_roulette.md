# DR-004 — Validation, Risk & Roulette Engine (Phase 7)

- **Status:** ACCEPTED
- **Selected Option:** Dedicated Darkoob Risk Gate (Non-bypassable)

## Evaluated Options
### Option 1: Dedicated Darkoob Risk Gate (Non-bypassable)
- **Pros:** Hard caps per global/account/channelxaccount; parser/AI cannot bypass.
- **Cons:** Custom implementation required.

### Option 2: Upstream inline lot sizing
- **Pros:** Minimal code.
- **Cons:** Lacks roulette persistence and multi-level hard caps.

## Rationale
Safety requirement: AI/OCR/parser outputs are untrusted proposals until validated by deterministic risk rules.
