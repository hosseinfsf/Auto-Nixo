# DR-003 — Persistence & State Machine (Phase 4)

- **Status:** ACCEPTED
- **Selected Option:** SQLite with WAL + Single-Writer Queue

## Evaluated Options
### Option 1: SQLite with WAL + Single-Writer Queue
- **Pros:** Zero external server, single-file backup, crash-safe atomic transactions.
- **Cons:** Single writer discipline required.

### Option 2: PostgreSQL Server
- **Pros:** Multi-writer concurrency.
- **Cons:** Heavy operational overhead for local Windows 11 8GB target.

## Rationale
Ideal for Windows 11 single-machine reliability with minimal RAM footprint and trivial backup/restore.
