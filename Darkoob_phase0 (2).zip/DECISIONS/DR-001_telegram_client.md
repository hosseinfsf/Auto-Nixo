# DR-001 — Telegram Listener (Phase 5)

- **Status:** PROPOSED
- **Selected Option:** Telethon (Isolated Process)

## Evaluated Options
### Option 1: Telethon (Isolated Process)
- **Pros:** Mature MTProto, event handlers, edit/delete detection, FloodWaitError support.
- **Cons:** Requires single-instance session lock.

### Option 2: Pyrogram / Kurigram
- **Pros:** Clean async API.
- **Cons:** Different session format than upstream FluentSignalCopier.

## Rationale
Isolated process with raw-first SQLite write and heartbeat ensures listener crashes never drop orders or leak state.
