# DR-002 — Signal Extraction & Normalization (Phase 6)

- **Status:** PROPOSED
- **Selected Option:** Adapter over Vendor + Darkoob Normalizer

## Evaluated Options
### Option 1: Adapter over Vendor + Darkoob Normalizer
- **Pros:** Deterministic, handles Persian/Arabic digits, zero LLM latency/cost on text.
- **Cons:** Needs table-driven fixtures for edge-case phrasing.

### Option 2: LLM-first Extraction
- **Pros:** Flexible on freeform prose.
- **Cons:** Non-deterministic, slower, quota-dependent.

## Rationale
Deterministic schema-first parsing with 13-class intent routing guarantees repeatable fixtures; ambiguous texts route to manual review.
