# DR-006 — Chart Image Intelligence (Phase 8)

- **Status:** PROPOSED
- **Selected Option:** Hybrid Local OCR + Chart Geometry + Optional Vision AI

## Evaluated Options
### Option 1: Hybrid Local OCR + Chart Geometry + Optional Vision AI
- **Pros:** Works offline when API quota exhausts; cross-checks price levels.
- **Cons:** Requires calibrated confidence fusion.

### Option 2: Cloud Vision API Only
- **Pros:** Fast setup.
- **Cons:** Fails offline and vulnerable to prompt injection without schema gate.

## Rationale
Treats all image text strictly as untrusted data and routes candidate disagreements to manual review.
