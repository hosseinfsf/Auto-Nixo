# Darkoob Safety & Isolation Statement (T-006)

1. Work strictly inside `D:\AutoTrades\Darkoob`.
2. **Forbidden / Read-Only Paths** (never modify, delete, or overwrite):
   - Any existing `FOREX-Trader`, `Nixo`, or `FluentSignalCopier` installations outside `D:\AutoTrades\Darkoob`.
   - Any existing MetaTrader 5 terminal binaries, profiles, or live accounts.
   - `_src/` after initial clone (treat as read-only upstream mirror).
   - `vendor/` files (must match upstream SHA-256; fixes go into `patches/` or `darkoob_integrations/`).
3. Real-money trading is disabled by default (`REAL_TRADING=false`, `ALLOW_REAL_ORDERS=false`) and requires Gate G3 human approval.
