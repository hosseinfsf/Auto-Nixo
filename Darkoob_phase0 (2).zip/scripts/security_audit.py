from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from darkoob.config import DarkoobSettings  # noqa: E402
from scripts.secret_scan import scan_path  # noqa: E402


def main() -> int:
    findings = scan_path(ROOT)
    if findings:
        print("SECURITY AUDIT FAILED (secrets detected):")
        for f in findings:
            print(" -", f)
        return 1

    settings = DarkoobSettings.from_env()
    if settings.real_trading and not (
        settings.gate_g3_approved and settings.allow_real_orders and not settings.demo_mode
    ):
        print("SECURITY AUDIT FAILED: REAL_TRADING=true in environment without full Gate G3 approval.")
        return 2

    print(
        f"SECURITY AUDIT PASSED: 0 secrets, bind={settings.dashboard_host}:{settings.dashboard_port}, demo_mode={settings.demo_mode}, gate_g3={settings.gate_g3_approved}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
