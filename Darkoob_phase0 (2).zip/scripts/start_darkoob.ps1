# Darkoob Local Startup & Pre-flight Check (T-211)
$ErrorActionPreference = "Stop"
Set-Location "D:\AutoTrades\Darkoob"

if (Test-Path ".\.venv\Scripts\Activate.ps1") {
    . .\.venv\Scripts\Activate.ps1
}

python scripts/secret_scan.py --self-test
python scripts/verify_checklist.py
python -m darkoob.dashboard_api
