from __future__ import annotations
import argparse
import re
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKIP_DIRS = {".git", "_src", ".venv", "venv", "data", "logs", "node_modules", "__pycache__"}
SKIP_FILES = {".env.example", "secret_scan.py"}

PATTERNS = [
    ("telegram_api_hash", re.compile(r"(?i)api_hash\s*[:=]\s*['\"]?[0-9a-f]{32}['\"]?")),
    ("telegram_session_string", re.compile(r"1[A-Za-z0-9_-]{80,}={0,2}")),
    ("openai_or_openrouter_key", re.compile(r"sk-(?:or-v1-)?[A-Za-z0-9_-]{20,}")),
    ("google_api_key", re.compile(r"AIza[0-9A-Za-z\-_]{35}")),
    ("private_key_block", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
]


def scan_path(base: Path) -> list[str]:
    findings = []
    for p in base.rglob("*"):
        if not p.is_file():
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        if p.name in SKIP_FILES:
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for name, rx in PATTERNS:
            if rx.search(text):
                findings.append(f"{p}: matched {name}")
    return findings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        with tempfile.TemporaryDirectory() as tmp:
            dummy = Path(tmp) / "leaked.txt"
            dummy.write_text("api_hash=" + ("a1b2c3d4" * 4) + "\n", encoding="utf-8")
            hits = scan_path(Path(tmp))
            if not hits:
                print("SELF-TEST FAILED: dummy secret not detected.")
                return 2
            print("SELF-TEST PASSED (planted secret detected):", hits[0])

    hits = scan_path(ROOT)
    if hits:
        print("SECRET SCAN FAILED:")
        for h in hits:
            print(" -", h)
        return 1
    print("SECRET SCAN PASSED: 0 findings.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
