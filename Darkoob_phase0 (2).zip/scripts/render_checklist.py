from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
data = json.loads((ROOT / "CHECKLIST.json").read_text(encoding="utf-8"))

lines = [
    "# Darkoob Master Checklist",
    "",
    f"- Updated: `{data['updated_at']}`",
    f"- Total tasks: `{len(data['tasks'])}`",
    "",
    "| ID | Phase | Status | Title | Depends On | Evidence Class |",
    "|---|---|---|---|---|---|",
]
for t in data["tasks"]:
    deps = ", ".join(t["depends_on"]) if t["depends_on"] else "-"
    ev = t["evidence_class"] or "-"
    lines.append(f"| {t['id']} | {t['phase']} | {t['status']} | {t['title']} | {deps} | {ev} |")

(ROOT / "CHECKLIST.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"Rendered CHECKLIST.md ({len(data['tasks'])} tasks)")
