from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
data = json.loads((ROOT / "CHECKLIST.json").read_text(encoding="utf-8"))
tasks = {t["id"]: t for t in data["tasks"]}
errors = []

if len(tasks) != len(data["tasks"]):
    errors.append("Duplicate task IDs detected.")

for t in data["tasks"]:
    if t["status"] == "PASSED":
        if not t.get("report") or not (ROOT / t["report"]).exists():
            errors.append(f"{t['id']}: PASSED but report missing ({t.get('report')})")
        if not t.get("commit"):
            errors.append(f"{t['id']}: PASSED but commit hash missing")
        if not t.get("acceptance_results"):
            errors.append(f"{t['id']}: PASSED but acceptance_results empty")
        for ar in t.get("acceptance_results", []):
            ev = ar.get("evidence")
            if not ar.get("met") or not ev or not (ROOT / ev).exists():
                errors.append(f"{t['id']}: unmet criterion or missing evidence ({ev})")
        for dep in t.get("depends_on", []):
            if dep in tasks and tasks[dep]["status"] != "PASSED":
                errors.append(f"{t['id']}: PASSED while dependency {dep} is {tasks[dep]['status']}")

if errors:
    print("CHECKLIST VERIFICATION FAILED:")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(f"CHECKLIST VERIFICATION PASSED ({len(tasks)} tasks checked).")
