//+------------------------------------------------------------------+
//|                                              DarkoobBridgeEA.mq5 |
//|                        Darkoob Signal & Risk Automation Bridge   |
//+------------------------------------------------------------------+
#property copyright "Darkoob"
#property version   "1.10"
#property description "File-bridge MQL5 EA with default-active Win/Loss Step Roulette, Gate G3 & foreign-magic protection."

#include <Trade\Trade.mqh>
#include <Darkoob\DarkoobRoulette.mqh>

input ulong  InpMagicNumber        = 202604;
input string InpCommandFile        = "darkoob\\commands.csv";
input string InpAckFile            = "darkoob\\acks.csv";
input int    InpTimerMs            = 250;
input ulong  InpSlippagePts        = 20;
input bool   InpAllowLiveAccount   = false;   // Gate G3: Keep false for DEMO-only; set true ONLY for authorized LIVE trading
input double InpMaxLotCap          = 5.0;

input group "=== Roulette Money Management (Active by Default) ==="
input bool                  InpRouletteEnabled      = true;
input ENUM_DARKOOB_RLT_MODE InpRouletteMode         = RLT_WIN_LOSS_STEP; // +1 on Win, -1 on Loss (floor 0)
input string                InpRouletteSourceKey    = "default";
input double                InpRouletteBaseLot      = 0.01;
input double                InpRouletteLotIncrement = 0.01;
input double                InpRouletteMultiplier   = 1.5;
input double                InpRouletteMaxLot       = 0.25;
input int                   InpRouletteMaxSteps     = 5;
input bool                  InpRouletteOverrideLot  = false; // If true or CSV lot <= 0, use Roulette lot

CTrade           g_trade;
CDarkoobRoulette g_roulette;
string           g_processedIds[];
ulong            g_closedPositions[];

//+------------------------------------------------------------------+
//| Deduplicate processed command IDs and closed position IDs        |
//+------------------------------------------------------------------+
bool IsCommandProcessed(const string cmdId)
  {
   int n = ArraySize(g_processedIds);
   for(int i = 0; i < n; i++)
     {
      if(g_processedIds[i] == cmdId)
         return true;
     }
   return false;
  }

void MarkCommandProcessed(const string cmdId)
  {
   int n = ArraySize(g_processedIds);
   if(n >= 2000)
     {
      for(int i = 0; i < n - 1; i++)
         g_processedIds[i] = g_processedIds[i + 1];
      g_processedIds[n - 1] = cmdId;
      return;
     }
   ArrayResize(g_processedIds, n + 1);
   g_processedIds[n] = cmdId;
  }

bool IsPositionSettled(const ulong posId)
  {
   int n = ArraySize(g_closedPositions);
   for(int i = 0; i < n; i++)
     {
      if(g_closedPositions[i] == posId)
         return true;
     }
   return false;
  }

void MarkPositionSettled(const ulong posId)
  {
   int n = ArraySize(g_closedPositions);
   if(n >= 2000)
     {
      for(int i = 0; i < n - 1; i++)
         g_closedPositions[i] = g_closedPositions[i + 1];
      g_closedPositions[n - 1] = posId;
      return;
     }
   ArrayResize(g_closedPositions, n + 1);
   g_closedPositions[n] = posId;
  }

//+------------------------------------------------------------------+
//| Load previously acknowledged command IDs across restarts         |
//+------------------------------------------------------------------+
void LoadAckHistory(void)
  {
   int handle = FileOpen(InpAckFile, FILE_READ | FILE_TXT | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(handle == INVALID_HANDLE)
      return;
   while(!FileIsEnding(handle))
     {
      string line = FileReadString(handle);
      StringTrimLeft(line);
      StringTrimRight(line);
      if(line == "")
         continue;
      string parts[];
      int count = StringSplit(line, ';', parts);
      if(count >= 1 && parts[0] != "" && parts[0] != "command_id")
         MarkCommandProcessed(parts[0]);
     }
   FileClose(handle);
  }

//+------------------------------------------------------------------+
//| Append acknowledgment line to MQL5\Files\darkoob\acks.csv        |
//+------------------------------------------------------------------+
void WriteAck(const string cmdId, const string status, const uint retcode, const ulong ticket, const string detail)
  {
   int handle = FileOpen(InpAckFile, FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(handle == INVALID_HANDLE)
      handle = FileOpen(InpAckFile, FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(handle == INVALID_HANDLE)
      return;
   FileSeek(handle, 0, SEEK_END);
   string row = cmdId + ";" + status + ";" + IntegerToString((long)retcode) + ";" + IntegerToString((long)ticket) + ";" + detail;
   FileWriteString(handle, row + "\r\n");
   FileClose(handle);
  }

//+------------------------------------------------------------------+
//| Normalize volume against broker SYMBOL_VOLUME_STEP / MIN / MAX   |
//+------------------------------------------------------------------+
double NormalizeLot(const string symbol, const double requestedLot)
  {
   double minLot  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);
   double stepLot = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
   if(stepLot <= 0.0)
      stepLot = 0.01;
   double capped = MathMin(requestedLot, InpMaxLotCap);
   if(maxLot > 0.0)
      capped = MathMin(capped, maxLot);
   double stepped = MathFloor(capped / stepLot) * stepLot;
   if(stepped < minLot)
      return 0.0;
   return NormalizeDouble(stepped, 2);
  }

double ResolveTradeLot(const string symbol, const double csvVol)
  {
   if(InpRouletteEnabled && (InpRouletteOverrideLot || csvVol <= 0.0))
      return NormalizeLot(symbol, g_roulette.GetLot(symbol));
   return NormalizeLot(symbol, csvVol);
  }

//+------------------------------------------------------------------+
//| Sum closed deals profit+commission+swap once whole pos closes    |
//+------------------------------------------------------------------+
double CalculateClosedPositionNetProfit(const ulong posId)
  {
   if(!HistorySelectByPosition(posId))
      return 0.0;
   double net = 0.0;
   int total = HistoryDealsTotal();
   for(int i = 0; i < total; i++)
     {
      ulong dealTicket = HistoryDealGetTicket(i);
      if(dealTicket == 0)
         continue;
      if((ulong)HistoryDealGetInteger(dealTicket, DEAL_MAGIC) != InpMagicNumber)
         continue;
      net += HistoryDealGetDouble(dealTicket, DEAL_PROFIT);
      net += HistoryDealGetDouble(dealTicket, DEAL_COMMISSION);
      net += HistoryDealGetDouble(dealTicket, DEAL_SWAP);
     }
   return net;
  }

//+------------------------------------------------------------------+
//| Execute one parsed command row                                   |
//| Format: command_id;action;symbol;volume;price;sl;tp              |
//+------------------------------------------------------------------+
void ExecuteCommandRow(const string &parts[])
  {
   string cmdId  = parts[0];
   string action = parts[1];
   string sym    = parts[2];
   double vol    = StringToDouble(parts[3]);
   double price  = StringToDouble(parts[4]);
   double sl     = StringToDouble(parts[5]);
   double tp     = StringToDouble(parts[6]);

   StringTrimLeft(cmdId);
   StringTrimRight(cmdId);
   StringTrimLeft(action);
   StringTrimRight(action);
   StringTrimLeft(sym);
   StringTrimRight(sym);

   if(cmdId == "" || cmdId == "command_id")
      return;
   if(IsCommandProcessed(cmdId))
      return;
   MarkCommandProcessed(cmdId);

   if(action == "ROULETTE_RESULT")
     {
      g_roulette.OnClosedResult(price);
      WriteAck(cmdId, "ROULETTE_UPDATED", 0, (ulong)g_roulette.GetStep(), "net=" + DoubleToString(price, 2));
      return;
     }

   if(action == "ROULETTE_RESET")
     {
      g_roulette.Reset();
      WriteAck(cmdId, "ROULETTE_RESET", 0, 0, "step=0");
      return;
     }

   long tradeMode = AccountInfoInteger(ACCOUNT_TRADE_MODE);
   if(tradeMode == ACCOUNT_TRADE_MODE_REAL && !InpAllowLiveAccount)
     {
      WriteAck(cmdId, "REFUSED_LIVE_GATE_G3", 0, 0, "InpAllowLiveAccount is false");
      return;
     }

   if(!SymbolSelect(sym, true))
     {
      WriteAck(cmdId, "REJECTED", 0, 0, "SymbolSelect failed");
      return;
     }

   int digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   double normSl = (sl > 0.0) ? NormalizeDouble(sl, digits) : 0.0;
   double normTp = (tp > 0.0) ? NormalizeDouble(tp, digits) : 0.0;
   double normPrice = (price > 0.0) ? NormalizeDouble(price, digits) : 0.0;
   string comment = StringSubstr("dk:" + cmdId, 0, 31);

   if(action == "BUY" || action == "SELL")
     {
      double safeLot = ResolveTradeLot(sym, vol);
      if(safeLot <= 0.0)
        {
         WriteAck(cmdId, "REJECTED", 0, 0, "Lot below broker minimum");
         return;
        }
      bool ok = (action == "BUY")
                ? g_trade.Buy(safeLot, sym, 0.0, normSl, normTp, comment)
                : g_trade.Sell(safeLot, sym, 0.0, normSl, normTp, comment);
      uint rc = g_trade.ResultRetcode();
      ulong ord = g_trade.ResultOrder();
      WriteAck(cmdId, ok ? "EXECUTED" : "FAILED", rc, ord, g_trade.ResultRetcodeDescription() + "|rlt_step=" + IntegerToString(g_roulette.GetStep()));
      return;
     }

   if(action == "BUY_LIMIT" || action == "SELL_LIMIT" || action == "BUY_STOP" || action == "SELL_STOP")
     {
      double safeLot = ResolveTradeLot(sym, vol);
      if(safeLot <= 0.0 || normPrice <= 0.0)
        {
         WriteAck(cmdId, "REJECTED", 0, 0, "Invalid pending lot or price");
         return;
        }
      bool ok = false;
      if(action == "BUY_LIMIT")
         ok = g_trade.BuyLimit(safeLot, normPrice, sym, normSl, normTp, ORDER_TIME_GTC, 0, comment);
      else if(action == "SELL_LIMIT")
         ok = g_trade.SellLimit(safeLot, normPrice, sym, normSl, normTp, ORDER_TIME_GTC, 0, comment);
      else if(action == "BUY_STOP")
         ok = g_trade.BuyStop(safeLot, normPrice, sym, normSl, normTp, ORDER_TIME_GTC, 0, comment);
      else
         ok = g_trade.SellStop(safeLot, normPrice, sym, normSl, normTp, ORDER_TIME_GTC, 0, comment);
      WriteAck(cmdId, ok ? "EXECUTED" : "FAILED", g_trade.ResultRetcode(), g_trade.ResultOrder(), g_trade.ResultRetcodeDescription());
      return;
     }

   if(action == "MOVE_BE" || action == "MODIFY_SLTP")
     {
      int touched = 0;
      int total = PositionsTotal();
      for(int i = total - 1; i >= 0; i--)
        {
         ulong ticket = PositionGetTicket(i);
         if(ticket == 0)
            continue;
         if((ulong)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber)
            continue;
         if(PositionGetString(POSITION_SYMBOL) != sym)
            continue;
         double curSl = PositionGetDouble(POSITION_SL);
         double curTp = PositionGetDouble(POSITION_TP);
         double newSl = (action == "MOVE_BE") ? NormalizeDouble(PositionGetDouble(POSITION_PRICE_OPEN), digits) : ((normSl > 0.0) ? normSl : curSl);
         double newTp = (normTp > 0.0) ? normTp : curTp;
         if(g_trade.PositionModify(ticket, newSl, newTp))
            touched++;
        }
      WriteAck(cmdId, (touched > 0) ? "MODIFIED" : "NO_MATCHING_POSITION", g_trade.ResultRetcode(), 0, "Managed magic only");
      return;
     }

   if(action == "PARTIAL_CLOSE")
     {
      int closed = 0;
      int total = PositionsTotal();
      for(int i = total - 1; i >= 0; i--)
        {
         ulong ticket = PositionGetTicket(i);
         if(ticket == 0)
            continue;
         if((ulong)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber)
            continue;
         if(PositionGetString(POSITION_SYMBOL) != sym)
            continue;
         double posVol = PositionGetDouble(POSITION_VOLUME);
         double reqPartial = (vol > 0.0) ? MathMin(vol, posVol) : (posVol * 0.5);
         double closeVol = NormalizeLot(sym, reqPartial);
         if(closeVol > 0.0 && g_trade.PositionClosePartial(ticket, closeVol))
            closed++;
        }
      WriteAck(cmdId, (closed > 0) ? "PARTIAL_CLOSED" : "NO_MATCHING_POSITION", g_trade.ResultRetcode(), 0, "Managed magic only");
      return;
     }

   if(action == "CLOSE_ALL")
     {
      int closed = 0;
      int total = PositionsTotal();
      for(int i = total - 1; i >= 0; i--)
        {
         ulong ticket = PositionGetTicket(i);
         if(ticket == 0)
            continue;
         if((ulong)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber)
            continue;
         if(sym != "*" && PositionGetString(POSITION_SYMBOL) != sym)
            continue;
         if(g_trade.PositionClose(ticket))
            closed++;
        }
      WriteAck(cmdId, (closed > 0) ? "CLOSED" : "NO_MATCHING_POSITION", g_trade.ResultRetcode(), 0, "Foreign manual trades untouched");
      return;
     }

   if(action == "CANCEL_PENDING")
     {
      int cancelled = 0;
      int total = OrdersTotal();
      for(int i = total - 1; i >= 0; i--)
        {
         ulong ticket = OrderGetTicket(i);
         if(ticket == 0)
            continue;
         if((ulong)OrderGetInteger(ORDER_MAGIC) != InpMagicNumber)
            continue;
         if(sym != "*" && OrderGetString(ORDER_SYMBOL) != sym)
            continue;
         if(g_trade.OrderDelete(ticket))
            cancelled++;
        }
      WriteAck(cmdId, (cancelled > 0) ? "CANCELLED" : "NO_MATCHING_ORDER", g_trade.ResultRetcode(), 0, "Managed magic only");
      return;
     }

   WriteAck(cmdId, "UNKNOWN_ACTION", 0, 0, action);
  }

//+------------------------------------------------------------------+
//| Poll MQL5\Files\darkoob\commands.csv                             |
//+------------------------------------------------------------------+
void PollCommandFile(void)
  {
   if(!FileIsExist(InpCommandFile))
      return;
   int handle = FileOpen(InpCommandFile, FILE_READ | FILE_TXT | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(handle == INVALID_HANDLE)
      return;

   while(!FileIsEnding(handle))
     {
      string line = FileReadString(handle);
      StringTrimLeft(line);
      StringTrimRight(line);
      if(line == "")
         continue;
      string parts[];
      int count = StringSplit(line, ';', parts);
      if(count >= 7)
         ExecuteCommandRow(parts);
     }
   FileClose(handle);
  }

//+------------------------------------------------------------------+
//| Track full position closures & update Roulette once per position |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans, const MqlTradeRequest &request, const MqlTradeResult &result)
  {
   if(!InpRouletteEnabled)
      return;
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD || trans.deal == 0)
      return;
   if(!HistoryDealSelect(trans.deal))
      return;
   if((ulong)HistoryDealGetInteger(trans.deal, DEAL_MAGIC) != InpMagicNumber)
      return;
   long entryType = HistoryDealGetInteger(trans.deal, DEAL_ENTRY);
   if(entryType != DEAL_ENTRY_OUT && entryType != DEAL_ENTRY_OUT_BY)
      return;

   ulong posId = (ulong)HistoryDealGetInteger(trans.deal, DEAL_POSITION_ID);
   if(posId == 0 || IsPositionSettled(posId))
      return;
   if(PositionSelectByTicket(posId))
      return; // Still partially open; wait for full close

   MarkPositionSettled(posId);
   double netProfit = CalculateClosedPositionNetProfit(posId);
   g_roulette.OnClosedResult(netProfit);
   WriteAck("rlt_" + IntegerToString((long)posId), "ROULETTE_STEP", 0, posId,
            "step=" + IntegerToString(g_roulette.GetStep()) + "|net=" + DoubleToString(netProfit, 2));
  }

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit(void)
  {
   long tradeMode = AccountInfoInteger(ACCOUNT_TRADE_MODE);
   if(tradeMode == ACCOUNT_TRADE_MODE_REAL && !InpAllowLiveAccount)
     {
      Print("DarkoobBridgeEA: Refusing LIVE account because InpAllowLiveAccount=false (Gate G3 safety lock).");
      return(INIT_FAILED);
     }

   if(!g_roulette.Init(
         InpRouletteSourceKey,
         InpMagicNumber,
         InpRouletteBaseLot,
         InpRouletteMode,
         InpRouletteLotIncrement,
         InpRouletteMultiplier,
         InpRouletteMaxLot,
         1,
         InpRouletteMode,
         0,
         1.0,
         1,
         InpRouletteMaxSteps,
         true,
         InpRouletteEnabled))
     {
      Print("DarkoobBridgeEA: Invalid Roulette parameters.");
      return(INIT_PARAMETERS_INCORRECT);
     }

   if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
      Print("DarkoobBridgeEA WARNING: Terminal Algo Trading is disabled.");
   if(!MQLInfoInteger(MQL_TRADE_ALLOWED))
      Print("DarkoobBridgeEA WARNING: EA Allow Algo Trading checkbox is disabled.");

   FolderCreate("darkoob");
   g_trade.SetExpertMagicNumber(InpMagicNumber);
   g_trade.SetDeviationInPoints(InpSlippagePts);
   g_trade.SetAsyncMode(false);

   LoadAckHistory();
   EventSetMillisecondTimer(InpTimerMs);
   PrintFormat("DarkoobBridgeEA initialized (mode=%s, magic=%I64u, roulette=%s, rlt_step=%d, next_lot=%.2f)",
               (tradeMode == ACCOUNT_TRADE_MODE_DEMO ? "DEMO" : "LIVE"),
               InpMagicNumber,
               (InpRouletteEnabled ? "ON" : "OFF"),
               g_roulette.GetStep(),
               g_roulette.GetLot(_Symbol));
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   EventKillTimer();
  }

//+------------------------------------------------------------------+
//| Expert timer & tick handlers                                     |
//+------------------------------------------------------------------+
void OnTimer(void)
  {
   PollCommandFile();
  }

void OnTick(void)
  {
   PollCommandFile();
  }
//+------------------------------------------------------------------+
