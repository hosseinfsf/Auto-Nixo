//+------------------------------------------------------------------+
//|                                               DarkoobRoulette.mqh|
//|                    Darkoob Roulette Money Management (MQL5)       |
//+------------------------------------------------------------------+
#ifndef __DARKOOB_ROULETTE_MQH__
#define __DARKOOB_ROULETTE_MQH__

enum ENUM_DARKOOB_RLT_MODE
  {
   RLT_CLASSIC         = 0, // Win: step +1; Loss: reset
   RLT_REVERSE         = 1, // Loss: step +1; Win: reset
   RLT_PAROLI          = 2, // Win: step +1; Loss: reset; cycles at max_steps
   RLT_FIXED_INCREMENT = 3, // Win: step +1; Loss: reset; base + step * increment
   RLT_MULTIPLIER      = 4, // Win: step +1; Loss: reset; base * multiplier^step
   RLT_WIN_LOSS_STEP   = 5  // Default: Win: step +1; Loss: step -1 (floor 0)
  };

class CDarkoobRoulette
  {
private:
   bool                  m_enabled;
   string                m_sourceKey;
   ulong                 m_magic;
   double                m_baseLot;
   ENUM_DARKOOB_RLT_MODE m_lotMode;
   double                m_lotIncrement;
   double                m_lotMultiplier;
   double                m_maxLot;
   int                   m_baseOrders;
   ENUM_DARKOOB_RLT_MODE m_orderMode;
   int                   m_orderIncrement;
   double                m_orderMultiplier;
   int                   m_maxOrders;
   int                   m_maxSteps;
   bool                  m_persist;
   int                   m_lotStep;
   int                   m_orderStep;
   string                m_gvLotKey;
   string                m_gvOrderKey;

   ulong HashKey(const string text) const
     {
      ulong h = 1469598103934665603ULL;
      int len = StringLen(text);
      for(int i = 0; i < len; i++)
        {
         h ^= (ulong)StringGetCharacter(text, i);
         h *= 1099511628211ULL;
        }
      return h;
     }

   void SaveState(void)
     {
      if(!m_persist)
         return;
      GlobalVariableSet(m_gvLotKey, (double)m_lotStep);
      GlobalVariableSet(m_gvOrderKey, (double)m_orderStep);
     }

   void LoadState(void)
     {
      if(!m_persist)
         return;
      if(GlobalVariableCheck(m_gvLotKey))
         m_lotStep = MathMax(0, MathMin(m_maxSteps, (int)MathRound(GlobalVariableGet(m_gvLotKey))));
      if(GlobalVariableCheck(m_gvOrderKey))
         m_orderStep = MathMax(0, MathMin(m_maxSteps, (int)MathRound(GlobalVariableGet(m_gvOrderKey))));
     }

   int AdvanceStep(const int currentStep, const ENUM_DARKOOB_RLT_MODE mode, const double netResult) const
     {
      if(MathAbs(netResult) <= 1e-9)
         return currentStep; // Break-even leaves step unchanged
      bool isWin = (netResult > 0.0);

      if(mode == RLT_WIN_LOSS_STEP)
        {
         if(isWin)
            return MathMin(m_maxSteps, currentStep + 1);
         return MathMax(0, currentStep - 1);
        }
      if(mode == RLT_PAROLI)
        {
         if(!isWin)
            return 0;
         return (currentStep + 1 > m_maxSteps) ? 0 : (currentStep + 1);
        }
      if(mode == RLT_REVERSE)
        {
         if(isWin)
            return 0;
         return MathMin(m_maxSteps, currentStep + 1);
        }
      // CLASSIC, FIXED_INCREMENT, MULTIPLIER
      if(isWin)
         return MathMin(m_maxSteps, currentStep + 1);
      return 0;
     }

   double ComputeRawLot(void) const
     {
      if(!m_enabled || m_lotStep <= 0)
         return m_baseLot;
      if(m_lotMode == RLT_PAROLI || m_lotMode == RLT_MULTIPLIER)
         return m_baseLot * MathPow(MathMax(1.0, m_lotMultiplier), m_lotStep);
      return m_baseLot + (double)m_lotStep * MathMax(0.0, m_lotIncrement);
     }

public:
   CDarkoobRoulette(void)
     {
      m_enabled = true;
      m_sourceKey = "default";
      m_magic = 0;
      m_baseLot = 0.01;
      m_lotMode = RLT_WIN_LOSS_STEP;
      m_lotIncrement = 0.01;
      m_lotMultiplier = 1.5;
      m_maxLot = 0.25;
      m_baseOrders = 1;
      m_orderMode = RLT_WIN_LOSS_STEP;
      m_orderIncrement = 0;
      m_orderMultiplier = 1.0;
      m_maxOrders = 1;
      m_maxSteps = 5;
      m_persist = true;
      m_lotStep = 0;
      m_orderStep = 0;
     }

   bool Init(
      const string sourceKey,
      const ulong magic,
      const double baseLot,
      const ENUM_DARKOOB_RLT_MODE lotMode = RLT_WIN_LOSS_STEP,
      const double lotIncrement = 0.01,
      const double lotMultiplier = 1.5,
      const double maxLot = 0.25,
      const int baseOrders = 1,
      const ENUM_DARKOOB_RLT_MODE orderMode = RLT_WIN_LOSS_STEP,
      const int orderIncrement = 0,
      const double orderMultiplier = 1.0,
      const int maxOrders = 1,
      const int maxSteps = 5,
      const bool persist = true,
      const bool enabled = true
   )
     {
      if(baseLot <= 0.0 || baseOrders < 1 || maxSteps < 1)
         return false;
      m_enabled = enabled;
      m_sourceKey = sourceKey;
      m_magic = magic;
      m_baseLot = baseLot;
      m_lotMode = lotMode;
      m_lotIncrement = MathMax(0.0, lotIncrement);
      m_lotMultiplier = MathMax(1.0, lotMultiplier);
      m_maxLot = MathMax(0.0, maxLot);
      m_baseOrders = baseOrders;
      m_orderMode = orderMode;
      m_orderIncrement = MathMax(0, orderIncrement);
      m_orderMultiplier = MathMax(1.0, orderMultiplier);
      m_maxOrders = MathMax(0, maxOrders);
      m_maxSteps = maxSteps;
      m_persist = persist;
      m_lotStep = 0;
      m_orderStep = 0;

      long login = AccountInfoInteger(ACCOUNT_LOGIN);
      ulong h = HashKey(IntegerToString(login) + "|" + IntegerToString((long)m_magic) + "|" + m_sourceKey);
      string prefix = "DkRLT_" + IntegerToString((long)h);
      m_gvLotKey = StringSubstr(prefix + "_L", 0, 62);
      m_gvOrderKey = StringSubstr(prefix + "_O", 0, 62);

      if(m_enabled)
         LoadState();
      return true;
     }

   void OnClosedResult(const double netResult)
     {
      if(!m_enabled)
         return;
      m_lotStep = AdvanceStep(m_lotStep, m_lotMode, netResult);
      m_orderStep = AdvanceStep(m_orderStep, m_orderMode, netResult);
      SaveState();
     }

   void Reset(void)
     {
      m_lotStep = 0;
      m_orderStep = 0;
      SaveState();
     }

   int GetStep(void) const
     {
      return m_enabled ? m_lotStep : 0;
     }

   double GetLot(const string symbol) const
     {
      double raw = ComputeRawLot();
      if(m_maxLot > 0.0)
         raw = MathMin(raw, m_maxLot);

      double minLot  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
      double maxLot  = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);
      double stepLot = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
      if(stepLot <= 0.0)
         stepLot = 0.01;
      if(maxLot > 0.0)
         raw = MathMin(raw, maxLot);

      double stepped = MathFloor(raw / stepLot) * stepLot;
      if(minLot > 0.0 && stepped < minLot)
         stepped = minLot;
      return NormalizeDouble(stepped, 2);
     }

   int GetOrders(void) const
     {
      if(!m_enabled || m_orderStep <= 0)
         return m_baseOrders;
      double raw = (m_orderMode == RLT_PAROLI || m_orderMode == RLT_MULTIPLIER)
                   ? ((double)m_baseOrders * MathPow(m_orderMultiplier, m_orderStep))
                   : ((double)m_baseOrders + (double)m_orderStep * (double)m_orderIncrement);
      int val = MathMax(1, (int)MathFloor(raw));
      if(m_maxOrders > 0)
         val = MathMin(val, m_maxOrders);
      return val;
     }
  };

#endif
